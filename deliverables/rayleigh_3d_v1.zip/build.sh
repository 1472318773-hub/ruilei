#!/usr/bin/env bash
set -euo pipefail
base="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
: "${FC:=gfortran}"
for site in 场地一 场地二 场地三; do
 mkdir -p "$base/$site/build"
 cd "$base/$site/build"
 "$FC" ${FC_EXTRA_FLAGS:-} -ffree-line-length-none -fallow-argument-mismatch -O3 -g -fopenmp -ffp-contract=off \
  ${CHECK_FLAGS:--fcheck=bounds} ../main.f90 ../indata.f90 ../openfile.f90 ../region.f90 ../dk.f90 ../green.f90 \
  ../integral.f90 ../gauss.f90 ../solv.f90 ../free.f90 -l:liblapack.so.3 -l:libblas.so.3 -o rayleigh > compile.log 2>&1
 echo "$site compiled"
done
