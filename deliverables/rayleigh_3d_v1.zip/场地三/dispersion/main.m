﻿clear all
global W;
global THETA;
THETA = 0;
c0 = 547;
c1 = 545;
q = 1e-8;

% === 根据 image.png 设定频率参数 ===
NE = 2048;
DT = 0.02;
f1 = 1/(NE*DT);  % 频率分辨率

num_points = 300;  % 0.10-12.06 Hz, step 0.04 Hz
n = 0;
for idx = 1:num_points
    % AT 代表频率序号，真实频率为 idx * f1，本次计算范围 0.10-12.06 Hz
    freq = 0.10 + (idx-1) * 0.04;
    AT = 4*pi*freq/197;
    W = 197 * AT / 2.0;
    n = n + 1;
    xxx(n) = AT;
    wlg(n) = freq;  % physical frequency (Hz)
    
    % 调用函数求解
    c2 = newton('fun443', c0, c1, q);
    c = newton3d('fun3d', c2, c2-0.01-0.0001i, q);
    % ... 后续计算 t(n), t1(n) 等保持不变 ...
  display(AT);
 display(c);
 %pause;
 t(n)=abs(c)^2/real(c);
 t1(n)=c;
    c0=t1(n)-0.01 ;%0.1;
    c1=t1(n)-0.0101 ;%0.1001;
 
%if AT>0.4
%    c0=t1(n)-819.0-50i;
%    c1=t1(n)-819.0001-72i;
%else
%   c0=t1(n)-0.1;
%   c1=t1(n)-0.101;
%end

rc(n)=real(c);
ic(n)=imag(c);
%save('mod2.txt','rc','ic','-ASCII','-append')
ratio(n)=ic(n)/rc(n);

% ===== added: only save complex Rayleigh phase velocity c for each frequency point =====
% One row corresponds to one AT point in the original loop.
% Column 1 = real(c), column 2 = imag(c).
cr(n)=real(c);
ci(n)=imag(c);
% ===== added end =====
end
lll=n;
realc=rc';
imc=ic';
hold on
plot(wlg,t)
fid=fopen('pinsan2.txt','w');
fic=fopen('pinsanratio2.txt','w');
for mi=1:lll
     fprintf(fid,'%12.8f %12.8f\r\n',wlg(mi),t(mi)/500);
     fprintf(fic,'%12.8f %12.8f\r\n',wlg(mi),ratio(mi));
end
fclose(fid);
fclose(fic);

% ===== added: write complex velocity table for Fortran =====
% File has no header and only two columns:
%   real(c)   imag(c)
% The i-th row corresponds to the i-th frequency point used above.
fv=fopen('rayleigh_complex_velocity.txt','w');
for mi=1:lll
     fprintf(fv,'(%.12f,%.12f)\r\n',cr(mi),ci(mi));
end
fclose(fv);
% ===== added end =====

% w1=0.05:1:999.05;
% w2=w1*30/352.84
% 
% 
% W=37.7;
% c0=500;
% c1=495;
% q=1e-8;
% for n=1:1000;
% c=newton('fun443',c0,c1,q);
% s(n)=abs(c)^2/real(c);
% s1(n)=c;
% W=W+1;
% c0=s1(n);
% c1=s1(n)-0.01;
% end;
% v1=37.7:1:1036.7;
% v2=v1*30/352.84;
% 
% 
% 
% W=90.4;
% c0=500;
% c1=495;
% q=1e-8;
% for n=1:1000;
% c=newton('fun443',c0,c1,q);
% l(n)=abs(c)^2/real(c);
% l1(n)=c;
% W=W+1;
% c0=l1(n);
% c1=l1(n)-0.2;
% end;
% u1=90.4:1:1089.4;
% u2=u1*30/352.84;
% 
% w3=0:1:999;
% plot(w2,t,v2,s,u2,l,w3,352.84*ones(1000),'--');
% axis([0,50,300,500]);
% xlabel('Ƶ{\omega}d/{c}_{s}^{L}');
% ylabel('ٶCa')