 
 
SUBROUTINE indata
  use quanju
  implicit none
  integer(long) i,j,id,L,ij,j1
  real(double) H,mu,L1,L2,L3,L4,L5,c1,c2,nxyz,xu((N1+NN1+1)*(M+1)),yu((N1+NN1+1)*(M+1)),zu(N1+NN1+1),VV,X0
    R=0.2d0
    HEIG=0.2D0
    H=15.6D0
    cs_L=197.0d0
    cs_R=545.0d0

    do i=1,N
      zna(i)=0.05d0
      znB(i)=0.05d0
      if(i.le.33)then
        cs(i)=197.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*197.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1930.0d0
      else if(i.le.35)then
        cs(i)=208.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*208.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1830.0d0
      else if(i.le.39)then
        cs(i)=235.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*235.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1890.0d0
      else if(i.le.48)then
        cs(i)=258.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*258.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=2010.0d0
      else if(i.le.57)then
        cs(i)=294.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*294.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1930.0d0
      else if(i.le.76)then
        cs(i)=314.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*314.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1920.0d0
      else if(i.le.91)then
        cs(i)=358.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*358.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1970.0d0
      else if(i.le.102)then
        cs(i)=398.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*398.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=1930.0d0
      else if(i.le.109)then
        cs(i)=459.0d0*SQRT(1+2.0*AII*znB(i))
        cp(i)=sqrt(3d0)*459.0d0*SQRT(1+2.0*AII*zna(i))
        P(i)=2010.0d0
      endif
      G(i)=cs(i)**2*P(i)
      LMD(i)=cp(i)**2*P(i)-2*G(i)
    enddo

    zna(N+1)=0.02d0
    znB(N+1)=0.02d0
    cs(N+1)=545.0d0*SQRT(1+2.0*AII*znB(N+1))
    cp(N+1)=sqrt(3d0)*545.0d0*SQRT(1+2.0*AII*zna(N+1))
    P(N+1)=1970.0d0
    G(N+1)=cs(N+1)**2*P(N+1)
    LMD(N+1)=cp(N+1)**2*P(N+1)-2*G(N+1)
    do i=1,N1+1  
          zu(i)=HEIG/(N1)*(I-1)
        enddo
        DO I=N1+2,N1+NN1+1
          zu(i)=HEIG !+0.1D0*HEIG*SIN(PI/2/NN1*(I+NN1-N1-1)) !0.1D0*R/NN1*(I-N1+NN1-1)
        END DO
        do i=1,N1
          d(i)=ABS(zu(i+1)-zu(i))
      z(i)=d(i)/2
      zm(i)=(zu(i)+zu(i+1))/2
        enddo
        do i=N1+1,N1+NN1
      zm(i)=HEIG
      Z(I)=0.0D0
        enddo
        do i=N1+1,N1+N2
          d(i)=(H-1.0D0*HEIG)/N2
    enddo 
    
    do i=1,N1+1
          do j=1,M+1
        xu((i-1)*(M+1)+j)=R*cos((j-1.5d0)*2*PI/M)
        yu((i-1)*(M+1)+j)=R*sin((j-1.5d0)*2*PI/M)
      enddo
        enddo
        do i=N1+2,N1+NN1+1
          do j=1,M+1
        xu((i-1)*(M+1)+j)=R*COS(PI/2/NN1*(I-N1-1))*cos((j-1.5d0)*2*PI/M)
        yu((i-1)*(M+1)+j)=R*COS(PI/2/NN1*(I-N1-1))*sin((j-1.5d0)*2*PI/M)
      enddo
        enddo
        do i=1,N1
          do j=1,M
            id=(i-1)*(M+1)+j
            xm2(i,j)=(xu(id)+xu(id+1)+xu(id+M+1)+xu(id+M+2))/4
        ym2(i,j)=(yu(id)+yu(id+1)+yu(id+M+1)+yu(id+M+2))/4
        nx2(i,j)=(yu(id+M+1)-yu(id+M+2))*d(i)
            ny2(i,j)=(xu(id+M+2)-xu(id+M+1))*d(i)
            nz2(i,j)=xu(id+M+1)*yu(id+M+2)-xu(id+M+1)*yu(id+1)-xu(id+1)*yu(id+M+2)-xu(id+M+2)*yu(id+M+1)+xu(id+M+2) &
  & *yu(id+1)+xu(id+1)*yu(id+M+1)
            nxyz=sqrt(nx2(i,j)**2+ny2(i,j)**2+nz2(i,j)**2)
        nx2(i,j)=nx2(i,j)/nxyz
            ny2(i,j)=ny2(i,j)/nxyz
            nz2(i,j)=nz2(i,j)/nxyz
            L1=sqrt((xu(id+M+1)-xu(id))**2+(yu(id+M+1)-yu(id))**2+d(i)**2)
            L2=sqrt((xu(id+M+1)-xu(id+M+2))**2+(yu(id+M+1)-yu(id+M+2))**2)
            L3=sqrt((xu(id+M+2)-xu(id+1))**2+(yu(id+M+2)-yu(id+1))**2+d(i)**2)
            L4=sqrt((xu(id+1)-xu(id))**2+(yu(id+1)-yu(id))**2)
            L5=sqrt((xu(id+M+2)-xu(id))**2+(yu(id+M+2)-yu(id))**2+d(i)**2)
            c1=(L1+L2+L5)/2
                c2=(L3+L4+L5)/2 
            sa(i)=sqrt(c1*(c1-L1)*(c1-L2)*(c1-L5))+sqrt(c2*(c2-L3)*(c2-L4)*(c2-L5))
        xm(i,j)=xm2(i,j)
        ym(i,j)=ym2(i,j) 
          enddo
          y1(i)=yu((i-1)*(M+1)+2)
          y2(i)=yu(i*(M+1)+2)
          DS2(i)=(y1(i)+y2(i))*d(i)
    enddo       
    do i=N1+1,N1+NN1
          do j=1,M
            id=(i-1)*(M+1)+j
            xm2(i,j)=(xu(id)+xu(id+1)+xu(id+M+1)+xu(id+M+2))/4
        ym2(i,j)=(yu(id)+yu(id+1)+yu(id+M+1)+yu(id+M+2))/4
        nx2(i,j)=0.0
            ny2(i,j)=0.0
            nz2(i,j)=-1.0D0
            L1=sqrt((xu(id+M+1)-xu(id))**2+(yu(id+M+1)-yu(id))**2)
            L2=sqrt((xu(id+M+1)-xu(id+M+2))**2+(yu(id+M+1)-yu(id+M+2))**2)
            L3=sqrt((xu(id+M+2)-xu(id+1))**2+(yu(id+M+2)-yu(id+1))**2)
            L4=sqrt((xu(id+1)-xu(id))**2+(yu(id+1)-yu(id))**2)
            L5=sqrt((xu(id+M+2)-xu(id))**2+(yu(id+M+2)-yu(id))**2)
            c1=(L1+L2+L5)/2
                c2=(L3+L4+L5)/2 
            sa(i)=sqrt(c1*(c1-L1)*(c1-L2)*(c1-L5))+sqrt(c2*(c2-L3)*(c2-L4)*(c2-L5))
        xm(i,j)=xm2(i,j)
        ym(i,j)=ym2(i,j) 
          enddo
          X0=(xu((i-1)*(M+1)+2)+xu((i-1)*(M+1)+1))*0.5D0
          x1(i)=xu((i-1)*(M+1)+2+(M+1))-X0
          x2(i)=xu((i-1)*(M+1)+1+(M+1))-X0
          y1(i)=yu((i-1)*(M+1)+2) 
          y2(i)=yu((i-1)*(M+1)+2+(M+1))
          
          an(i)=(y2(i)-y1(i))/x2(i)
          bn(i)=y1(i) 
          cn(i)=-an(i)
          dn(i)=-y1(i)                                                                    
    enddo       
        
        do i=1,N1+NN1
          do j=1,M      
        xmx2(:,j,i)=xm2(:,j)-xu((i-1)*(M+1)+1)
          enddo
        enddo
    

    xm(F2:N1,:)=0d0; ym(F2:N1,:)=0d0
    do ij=Z1+1,NZ
      call image(ij,i,j,L)
      do j1=1,L
        xm(i,j)=xm(i,j)+xm2(i,(j-1)*L+j1)/L
        ym(i,j)=ym(i,j)+ym2(i,(j-1)*L+j1)/L
      enddo
    enddo 
    do i=1,N1
      zm(i)=(zu(i)+zu(i+1))/2
    enddo
    
      
end subroutine





subroutine image(ij,i,j,L)
  use e_digit
  implicit none
  integer(long) ij,i,j,L,U
    U=ij-(ij-1)/NZ*NZ
    if(U<=Z1)then
      i=(U-1)/M+1; j=U-(i-1)*M; L=1
    else if(U>Z1.AND.U<=Z1+Z2)then
      i=F2+(U-Z1-1)/M2; j=(U-Z1)-(i-F2)*M2; L=2
    else if(U>Z1+Z2.AND.U<=Z1+Z2+Z4)then
      i=F4+(U-Z1-Z2-1)/M4; j=(U-Z1-Z2)-(i-F4)*M4; L=4 
    else if(U>Z1+Z2+Z4.AND.U<=Z1+Z2+Z4+Z8)then           
      i=F8+(U-Z1-Z2-Z4-1)/M8; j=(U-Z1-Z2-Z4)-(i-F8)*M8; L=8          
    else
      i=F16+(U-Z1-Z2-Z4-Z8-1)/M16; j=(U-Z1-Z2-Z4-Z8)-(i-F16)*M16; L=16
    endif
end subroutine
