 
module e_digit
  integer,parameter:: double=selected_real_kind(13,200)
  integer,parameter:: long=selected_int_kind(7)
  integer(long) Z1,Z2,Z4,Z8,Z16,NZ
  integer(long),parameter:: N1=32,N2=95
  integer(long),parameter:: NN1=8,M=64,N=N1+N2,NT=(N1+NN1)*M,N0=5
  integer(long),parameter:: M2=M/2,M4=M/4,M8=M/8,M16=M/16
  integer(long),parameter:: F2=N1+NN1+1,F4=N1+NN1+1,F8=N1+NN1+1,F16=N1+NN1+1    
  integer(long),parameter:: IC=12
  real(double),parameter:: PI=3.1415926535897932d0
  complex(double),parameter:: AII=(0d0,1d0) 
end module     

module quanju
  use e_digit   
  real(double),save:: x1(N1+NN1),x2(N1+NN1),x3(N1+NN1),y1(N1+NN1),y2(N1+NN1),y3(N1+NN1),sa(N1+NN1),z(N1+NN1),w, &
  & cs_L,cs_R,zna(N+1),znB(N+1),P(N+1),D(N),R,HEIG
  real(double),save:: nx1(N1+NN1,M),ny1(N1+NN1,M),nz1(N1+NN1,M),DS1(N1+NN1),xm1(N1+NN1,M),ym1(N1+NN1,M),xmx1(N1+NN1,M,N1+NN1)
  real(double),save:: nx2(N1+NN1,M),ny2(N1+NN1,M),nz2(N1+NN1,M),DS2(N1+NN1),xm2(N1+NN1,M),ym2(N1+NN1,M),xmx2(N1+NN1,M,N1+NN1)
  real(double),save:: xm(N1+NN1,M),ym(N1+NN1,M),zm(N1+NN1)
  real(double),save:: an(N1+NN1),bn(N1+NN1),cn(N1+NN1),dn(N1+NN1),en(N1+NN1)
  complex(double),save:: CS(N+1),CP(N+1),G(N+1),LMD(N+1),CA
  complex(double),save:: E1ni(4,4,N1+1),E1_ni(4,4,N1+1),II(6,6),K1(2*(N+1),4),K2(N+1,3),Ehf(3,3),E3HE1(3,6), &
  & E4HE1(6,6),E1(4,4,N+1),E2(2,2,N+1),E13(2,4,N1+1),E14(4,4,N1+1)
  complex(double),save:: K(3*(N+1),6),E(6,6,N),E1_niF(6,6,N),E3(3,6,N1),E4(6,6,N1),E3HE1F(3,6),E4HE1F(6,6), &
  & SS(3*(N+1),3*(N+1))
  integer(long),parameter:: XC=16
  !$OMP threadprivate(E1_ni,E1ni,K1,K2,E3HE1,E4HE1,E1,E2,E13,E14)
end module



program MAIN
  use quanju
  use, intrinsic :: ieee_arithmetic
  use omp_lib, only: omp_get_wtime
  implicit none
  interface 
    
    subroutine integral(Gv1,Gs1)
          use quanju
      implicit none
     integer(long),parameter:: NJ=1200,ND=100
    integer(long) U,i,j,i1,j1,j11,id,ij,G1,G2,G3,G4,ierr,iL,iR
    real(double) length,thta,time
    complex(double) kx,ky,KXY,Gs1(:,:),Gv1(:,:)
        complex(double) T1(6,N1+NN1,M,N1+NN1),T2(6,N1+NN1,M,N1+NN1),T3(6,N1+NN1,M,N1+NN1),W1(3,N1+NN1,M,N1+NN1),W2(3, &
  & N1+NN1,M,N1+NN1),W3(3,N1+NN1,M,N1+NN1)
    complex(double) RT1(6,N1+NN1,M,N1+NN1),RT2(6,N1+NN1,M,N1+NN1),RT3(6,N1+NN1,M,N1+NN1),RW1(3,N1+NN1,M,N1+NN1), &
  & RW2(3,N1+NN1,M,N1+NN1),RW3(3,N1+NN1,M,N1+NN1)
    complex(double) UWUNIT(2,4,N1+1,N1),TXYZUNIT(4,4,N1+1,N1),VVUNIT(2,N1+1,N1),tYzUNIT(2,N1+1,N1),tYXUNIT(2,N1+1,N1)
    complex(double) UWBUNIT(2,4,N1+1),TXYZBUNIT(4,4,N1+1),VVBUNIT(N1+1),tYzBUNIT(N1+1),tYXBUNIT(N1+1)
    real(double)  DUANK(NJ),DUANKX(ND,NJ),DUANKY(ND,NJ),DKS(NJ)
    end subroutine
    subroutine freefield(IP,ALFX,ALFY,tf,vf)
          use quanju
          implicit none 
          integer(long) IP,i,j,ij,h,L,jh
          real(double) ALFX,ALFY,AP,ASV,ASH
      complex(double) dis(3,N1),str(6,N1),AB(6),as,lx,ly,lz,mx,my,mz,kx,ky,kpz,ksz,C1(3,3),C2(3,3),C3(3,3),BPSvSh(3),u0,v0,w0
          complex(double) node(3*(N+1)),uvw(3*(N+1)+10) 
      complex(double) tf(:),vf(:)
    end subroutine
  end interface
  integer(long) U,IP,i,j,i1,j1,ij,ij1,JC,rank,ierr,kuan,KL,ZL,O,L,L1,C,CR,CM,IFREQ,NFREQ,IOSTAT_RUN
  real(double) faix,faiy,thta,ETA,FREQ,STAGE_T0,FREQ_T0,TNOW
  logical FREE_ONLY
  real(double) WALL_T0,STAGE_W0
  character(32) RUN_ARGUMENT
  complex(double) Kjc(6,6),delta(6,IC),wyf(N0,5,3,IC),wy(N0,5,3,IC)
  complex(double),allocatable:: cof(:,:),tf(:,:),vf(:,:),vs(:,:),Gs(:,:),Gv(:,:),dw1(:,:),lm(:,:),Fv(:,:),Gv1(:,:),Gs1(:,:)
  
    NFREQ=1
    if(command_argument_count()>0)then
      call get_command_argument(1,RUN_ARGUMENT)
      read(RUN_ARGUMENT,*,iostat=IOSTAT_RUN) NFREQ
      if(IOSTAT_RUN/=0) error stop 'NFREQ must be an integer'
    endif
    if(NFREQ<1.or.NFREQ>300) error stop 'NFREQ must be 1..300'
    FREE_ONLY=.false.
    if(command_argument_count()>1)then
      call get_command_argument(2,RUN_ARGUMENT)
      if(trim(RUN_ARGUMENT)/='--free-only') error stop 'Unknown second argument'
      FREE_ONLY=.true.
    endif
    call openfile
    Z1=(F2-1)*M
    Z2=(F4-F2)*M2
    Z4=(F8-F4)*M4 
    Z8=(F16-F8)*M8
    Z16=(N1+NN1-F16+1)*M16
    NZ=Z1+Z2+Z4+Z8+Z16
    
   
    call indata

    K1=(0d0,0d0);K2=(0d0,0d0);E1_ni=(0d0,0d0);II=(0d0,0d0);E1=(0d0,0d0);E2=(0d0,0d0)
    do i=1,6
      II(i,i)=(1d0,0d0)   !!!! very important
    enddo
    


    open(1011,file='CA.txt',status='old',action='read')
    do IFREQ=1,NFREQ
      FREQ=0.10d0+0.04d0*dble(IFREQ-1)
      read(1011,*,iostat=IOSTAT_RUN) CA
      if(IOSTAT_RUN/=0) error stop 'Invalid or missing CA row'
      ETA=2d0*PI*FREQ/cs_L
      call cpu_time(FREQ_T0)
      WALL_T0=omp_get_wtime()
      write(*,*) 'FREQUENCY_BEGIN',IFREQ,FREQ
      flush(6)
      
      write(1010,*) ETA
      write(*,*) ETA
      w=cs_L*ETA/R
      if(FREE_ONLY)then
        allocate(tf(3*NZ,1),vf(3*NZ,1))
        call freefield(0,0d0,90d0,tf(:,1),vf(:,1))
        if(.not.all(ieee_is_finite(abs(vf))).or..not.all(ieee_is_finite(abs(tf)))) &
          error stop 'Nonfinite free field'
        write(*,*) 'FREE_FIELD_COMPLETE',IFREQ,FREQ,maxval(abs(vf)),maxval(abs(tf))
        deallocate(tf,vf)
        cycle
      endif
      allocate(Gs1(3*NT,3*(N1+NN1)),Gv1(3*NT,3*(N1+NN1)),stat=ierr)
      call cpu_time(STAGE_T0)
      STAGE_W0=omp_get_wtime()
      call integral(Gv1,Gs1)
      call report_stage('integral',STAGE_T0) 
          allocate(Gv(3*NZ,3*NZ),Gs(3*NZ,3*NZ),stat=ierr)
          
      call cpu_time(STAGE_T0)
      STAGE_W0=omp_get_wtime()
      Gv=(0d0,0d0); Gs=(0d0,0d0)
      do IJ=1,3*NZ
        O=(ij-1)/NZ
        call image(ij,i,j,L)
        do ij1=1,NZ
          call image(ij1,i1,j1,L1)
          call GvGs(L,L1)
        enddo
      enddo      
      
      call report_stage('assembly',STAGE_T0)
      deallocate(Gs1,Gv1)
      allocate(dw1(3*NZ,6),lm(3*NZ,6),Fv(3*NZ,6),stat=ierr)
      
          dw1=(0d0,0d0)
      dw1(1:NZ,1)=(1d0,0d0)
      dw1(NZ+1:2*NZ,2)=(1d0,0d0)
      dw1(2*NZ+1:3*NZ,3)=(1d0,0d0)
      do ij=1,NZ
        call image(ij,i,j,L)
        dw1(NZ+ij,4)=(zm(i)); dw1(2*NZ+ij,4)=-ym(i,j)
        dw1(ij,5)=-(zm(i));   dw1(2*NZ+ij,5)=xm(i,j)
            dw1(ij,6)=ym(i,j);  dw1(NZ+ij,6)=-xm(i,j)
      enddo
      
      call cpu_time(STAGE_T0)
      STAGE_W0=omp_get_wtime()
      CALL supGAUSS(GV,DW1,LM,3*NZ,6)
      call report_stage('supGAUSS',STAGE_T0)
      call check_rigid_solve
      call cpu_time(STAGE_T0)
      STAGE_W0=omp_get_wtime()
      CALL PXP(Gs,lm,Fv,3*NZ,3*NZ,6)
      call report_stage('PXP',STAGE_T0)
      deallocate(Gs)
      
      call tx(dw1,Fv,Kjc,3*NZ,6,6)         !Kjc=(.t.dw1).x.Fv
      
      allocate(vf(3*NZ,IC),tf(3*NZ,IC),vs(3*NZ,IC),stat=ierr)
      call cpu_time(STAGE_T0)
      STAGE_W0=omp_get_wtime()
      call jc_delta
      if(maxval(abs(delta(:,1)))<=tiny(1d0)) error stop 'Unexpected all-zero Rayleigh delta'
      if(.not.all(ieee_is_finite(abs(Kjc))).or..not.all(ieee_is_finite(abs(delta(:,1))))) &
        error stop 'Nonfinite K or delta: frequency not written'
        !write(1010,*) 'write K,Fv,lm'
        write(2001,*) Kjc(1,1)/(cs_L**2*p(1)) 
        write(2002,*) Kjc(3,3)/(cs_L**2*p(1)) 
        write(2003,*) Kjc(4,4)/(cs_L**2*p(1)) 
        write(2004,*) Kjc(6,6)/(cs_L**2*p(1)) 
        write(2005,*) Kjc(1,5)/(cs_L**2*p(1)) 
        write(2006,*) Kjc(5,1)/(cs_L**2*p(1))
      

      do i=1,6
        write(3000+i,*) delta(i,1)
        flush(3000+i)
        flush(2000+i)
      enddo
      write(1012,'(i6,1x,f10.4,1x,es24.15)') IFREQ,FREQ,w
      flush(1012)
      call report_stage('jc_delta',STAGE_T0)
      call cpu_time(TNOW)
      write(*,*) 'FREQUENCY_COMPLETE',IFREQ,FREQ,'CPU_SECONDS',TNOW-FREQ_T0,'WALL_SECONDS',omp_get_wtime()-WALL_T0
      flush(6)

      deallocate(Gv,dw1,lm,Fv,vf,tf,vs)
  
    enddo

        


    contains
      subroutine check_rigid_solve
        complex(double),allocatable:: residual(:,:)
        real(double) den,rel
        allocate(residual(3*NZ,6))
        residual=matmul(Gv,lm)-dw1
        den=maxval(sum(abs(Gv),dim=2))*maxval(abs(lm))+maxval(abs(dw1))
        rel=maxval(abs(residual))/max(den,tiny(1d0))
        write(*,*) 'RIGID_LINEAR_RESIDUAL',rel
        if(.not.ieee_is_finite(rel).or.rel>1d-8) error stop 'Rigid solve residual exceeded 1e-8'
        deallocate(residual)
      end subroutine
      subroutine report_stage(label,tstart)
        character(*) label
        real(double) tstart,tend
        call cpu_time(tend)
        write(*,*) 'STAGE_COMPLETE',label,' CPU_SECONDS ',tend-tstart,' WALL_SECONDS ',omp_get_wtime()-STAGE_W0
        flush(6)
      end subroutine
      subroutine GvGs(L,L1)
        integer(long) L,L1,h,h1,jh,j1h,id
        complex(double) Gvh(3),Gsh(3)
          do h=1,L
            jh=(j-1)*L+h
            thta=(jh-1)*2*PI/M
            do h1=1,L1
              j1h=(j1-1)*L1+h1
              if(j1h<=jh-1)then
                id=(i1-1)*M+j1h-jh+1+M
              else
                id=(i1-1)*M+j1h-jh+1
              endif
              Gvh(1)=Gv1(id,i+O*(N1+NN1))*cos(thta)-Gv1(id+NT,i+O*(N1+NN1))*sin(thta)
              Gvh(2)=Gv1(id,i+O*(N1+NN1))*sin(thta)+Gv1(id+NT,i+O*(N1+NN1))*cos(thta)
              Gvh(3)=Gv1(id+2*NT,i+O*(N1+NN1))
              Gsh(1)=Gs1(id,i+O*(N1+NN1))*cos(thta)-Gs1(id+NT,i+O*(N1+NN1))*sin(thta)
              Gsh(2)=Gs1(id,i+O*(N1+NN1))*sin(thta)+Gs1(id+NT,i+O*(N1+NN1))*cos(thta)
              Gsh(3)=Gs1(id+2*NT,i+O*(N1+NN1))
              Gv(ij1,IJ)=Gv(ij1,IJ)+Gvh(1)/L1
              Gv(NZ+ij1,IJ)=Gv(NZ+ij1,IJ)+Gvh(2)/L1
              Gv(2*NZ+ij1,IJ)=Gv(2*NZ+ij1,IJ)+Gvh(3)/L1
              Gs(ij1,IJ)=Gs(ij1,IJ)+Gsh(1)*sa(i1)
              Gs(NZ+ij1,IJ)=Gs(NZ+ij1,IJ)+Gsh(2)*sa(i1)
              Gs(2*NZ+ij1,IJ)=Gs(2*NZ+ij1,IJ)+Gsh(3)*sa(i1)
            enddo
          enddo 
      end subroutine
      subroutine jc_delta
        complex(double) delta1(6,IC),check_rhs(6)
        real(double) solve_residual,den
        delta1=(0d0,0d0)
        ! Single Rayleigh wave propagating along +x; not a P/SV/SH case.
        call freefield(0,0d0,90d0,tf(:,1),vf(:,1))
        do i=1,6
          do j=1,3*NZ
            delta1(i,1)=delta1(i,1)+Fv(j,i)*vf(j,1)-dw1(j,i)*tf(j,1)
          enddo
        enddo
        call GAUSS(Kjc,delta1(:,1),delta(:,1),6,1)
        check_rhs=matmul(Kjc,delta(:,1))-delta1(:,1)
        den=maxval(sum(abs(Kjc),dim=2))*maxval(abs(delta(:,1)))+maxval(abs(delta1(:,1)))
        solve_residual=maxval(abs(check_rhs))/max(den,tiny(1d0))
        write(*,*) 'DELTA_LINEAR_RESIDUAL',solve_residual
        if(.not.ieee_is_finite(solve_residual).or.solve_residual>1d-8) &
          error stop 'Delta linear solve residual exceeded 1e-8'
      end subroutine

end program main
        



         


