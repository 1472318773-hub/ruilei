! Rayleigh-only completion of the missing excitation in the supplied free.F90.
! Original DKFREE, E1_niF, E3/E4, geometry and phase convention are retained.
subroutine freefield(IP,faix,faiy,tf,vf)
 use quanju
 use, intrinsic :: ieee_arithmetic
 implicit none
 integer(long) IP,i,j,ij,h,L,jh,info,lwork,ndof,imode,q
 real(double) faix,faiy,score,best,transverse,normv,den,rel,rowrel
 real(double),allocatable:: rwork(:),rowden(:)
 complex(double) tf(:),vf(:),ab(6),as,kx,ky,dis(3,N1+NN1),str(6,N1+NN1)
 complex(double) uvw(3*(N+1)+10),scale,zquery(1),vl_dummy(1,1)
 complex(double),allocatable:: a(:,:),eig(:),vr(:,:),work(:),res(:)
 if(IP/=0.or.abs(faix)>1d-12) error stop 'This build requires Rayleigh IP=0, azimuth=0 deg'
 if(abs(CA)<tiny(1d0).or..not.ieee_is_finite(abs(CA))) error stop 'Invalid CA'
 if(size(tf)/=3*NZ.or.size(vf)/=3*NZ) error stop 'Invalid free-field array size'
 kx=w/CA
 ky=(0d0,0d0)
 call DKFREE(kx,ky)
 ndof=3*(N+1)
 allocate(a(ndof,ndof),eig(ndof),vr(ndof,ndof),rwork(2*ndof),res(ndof),rowden(ndof))
 a=SS
 ! LAPACK query preserves all requested eigenvectors; no fixed 1000-element workspace.
 call zgeev('N','V',ndof,a,ndof,eig,vl_dummy,1,vr,ndof,zquery,-1,rwork,info)
 if(info/=0) error stop 'ZGEEV workspace query failed'
 lwork=max(2*ndof,ceiling(real(zquery(1),double)))
 allocate(work(lwork))
 a=SS
 call zgeev('N','V',ndof,a,ndof,eig,vl_dummy,1,vr,ndof,work,lwork,rwork,info)
 if(info/=0) error stop 'ZGEEV did not converge'
 ! At ky=0 the SH subspace (y displacement) decouples. Keep P-SV modes.
 ! CA is provided, not recomputed. Select its nearest-null sagittal mode.
 imode=0;best=huge(1d0)
 do q=1,ndof
   normv=sqrt(sum(abs(vr(:,q))**2))
   transverse=sqrt(sum(abs(vr(2:ndof:3,q))**2))/max(normv,tiny(1d0))
   if(transverse>1d-6) cycle
   if(abs(vr(3,q))<=1d-10*maxval(abs(vr(:,q)))) cycle
   score=abs(eig(q))
   if(score<best)then
     best=score;imode=q
   endif
 enddo
 if(imode==0) error stop 'No sagittal mode with nonzero surface vertical displacement'
 ! Original transformed nodal coordinate is q_z=i*u_z (see E1F versus E3).
 ! Therefore divide by VR(3)/i so physical surface u_z is +1+0i.
 scale=vr(3,imode)/AII
 uvw=(0d0,0d0)
 uvw(1:ndof)=vr(:,imode)/scale
 if(.not.all(ieee_is_finite(abs(uvw)))) error stop 'Nonfinite Rayleigh mode'
 res=matmul(SS,uvw(1:ndof))
 den=maxval(sum(abs(SS),dim=2))*maxval(abs(uvw(1:ndof)))
 rel=maxval(abs(res))/max(den,tiny(1d0))
 rowden=matmul(abs(SS),abs(uvw(1:ndof)))
 ! Ignore an exactly decoupled transverse zero equation when scaling row residuals.
 rowrel=0d0
 do q=1,ndof
   if(mod(q,3)==2) cycle
   rowrel=max(rowrel,abs(res(q))/max(rowden(q),tiny(1d0)))
 enddo
 write(*,*) 'RAYLEIGH_MODE', 'LAMBDA',eig(imode),'NORM_RESIDUAL',rel,'ROW_RESIDUAL',rowrel
 write(*,*) 'SURFACE_PHYSICAL_U',uvw(1),uvw(2),uvw(3)/AII
 flush(6)
 ! A near-null eigenvector is an explicit trial-model completion, not an exact CA root.
 ! Stop on gross inconsistency; expose smaller discrepancies in the run log.
 if(.not.ieee_is_finite(rel).or..not.ieee_is_finite(rowrel)) error stop 'Invalid modal residual'
 if(rowrel>1d-2) error stop 'CA/mode incompatible: row residual > 1e-2; no final output'
 if(rowrel>1d-6) write(*,*) 'WARNING: supplied CA gives an approximate near-null mode; inspect residual'
 dis=(0d0,0d0);str=(0d0,0d0)
 do i=1,N1
   call pxp(E1_niF(:,:,i),uvw(3*i-2:3*i+3),ab,6,6,1)
   call pxp(E3(:,:,i),ab,dis(:,i),3,6,1)
   call pxp(E4(:,:,i),ab,str(:,i),6,6,1)
 enddo
 call pxp(E1_niF(:,:,N1+1),uvw(3*(N1+1)-2:3*(N1+1)+3),ab,6,6,1)
 call pxp(E3HE1F,ab,dis(:,N1+1),3,6,1)
 call pxp(E4HE1F,ab,str(:,N1+1),6,6,1)
 do i=N1+2,N1+NN1
   dis(:,i)=dis(:,N1+1);str(:,i)=str(:,N1+1)
 enddo
 vf=(0d0,0d0);tf=(0d0,0d0)
 ! One pass over all elements, with valid bottom values; removes the original
 ! out-of-bounds preliminary pass and later overwrites. Current project has L=1.
 do ij=1,NZ
   call image(ij,i,j,L)
   do h=1,L
     jh=(j-1)*L+h
     as=exp(-AII*kx*xm2(i,jh))*exp(-AII*ky*ym2(i,jh))
     if(abs(as)<tiny(1d0).or..not.ieee_is_finite(abs(as))) error stop 'Invalid phase factor'
     ! Retain the original phase-only as/abs(as) convention.
     vf(ij)=vf(ij)+dis(1,i)*as/abs(as)/L
     vf(NZ+ij)=vf(NZ+ij)+dis(2,i)*as/abs(as)/L
     vf(2*NZ+ij)=vf(2*NZ+ij)+dis(3,i)*as/abs(as)/L
     tf(ij)=tf(ij)+(str(1,i)*nx2(i,jh)+str(4,i)*ny2(i,jh)+str(5,i)*nz2(i,jh))*as/abs(as)*sa(i)
     tf(NZ+ij)=tf(NZ+ij)+(str(4,i)*nx2(i,jh)+str(2,i)*ny2(i,jh)+str(6,i)*nz2(i,jh))*as/abs(as)*sa(i)
     tf(2*NZ+ij)=tf(2*NZ+ij)+(str(5,i)*nx2(i,jh)+str(6,i)*ny2(i,jh)+str(3,i)*nz2(i,jh))*as/abs(as)*sa(i)
   enddo
 enddo
 if(.not.all(ieee_is_finite(abs(vf))).or..not.all(ieee_is_finite(abs(tf)))) error stop 'Nonfinite free field'
 if(maxval(abs(vf))<tiny(1d0)) error stop 'Unexpected zero normalized Rayleigh field'
end subroutine
