

  subroutine DK(kxy)
        use quanju      
        implicit none
        integer(long) U,I
        real(double) YITA
        complex(double) kx,ky,KXYT,lx,mx,ly,my,lz,mz,kpz,ksz,S1,S2,S3,S4,S5,fu,LMD2G,mx1,my1,mxmz,mymz,ES,ET,Kxy,t,DD, &
  & sksd,cksd,sktd,cktd,t2,A1,IIPSV(4,4),EE(4,4)
          
          IIPSV=(0d0,0d0);E1=(0d0,0d0);EE=(0d0,0d0);E1_ni=(0d0,0d0);E2=(0d0,0d0);K1=(0d0,0d0);K2=(0d0,0d0);E13=(0.0,0.0); &
  & E14=(0.0,0.0);E1ni=(0.0,0.0)
      do U=1,4
        IIPSV(U,U)=(1d0,0d0)
      enddo
          do U=1,N
        mx=cs(u)*kxy/w; t=-AII*sqrt(1-1/mx**2);  t=abs(dble(t))-AII*abs(dimag(t));    sktd=sin(kxy*t*d(u)); &
  & cktd=cos(kxy*t*d(u))
        lx=cp(u)*kxy/w; s1=-AII*sqrt(1-1/lx**2); s1=abs(dble(s1))-AII*abs(dimag(s1)); sksd=sin(kxy*s1*d(u)); &
  & cksd=cos(kxy*s1*d(u))
            DD=(1+t*t)*kxy*G(u)/(2*(1-cksd*cktd)+(s1*t+1/s1/t)*sksd*sktd)
        t2=t*t
        
        E1(1,1,U)=(cksd*sktd/t+s1*sksd*cktd)*DD
        E1(1,2,U)=((3-t2)/(1+t2)*(1-cksd*cktd)+(1+2*s1*s1*t2-t2)/s1/t/(1+t2)*sksd*sktd)*DD
            E1(1,3,U)=(-s1*sksd-sktd/t)*DD
            E1(1,4,U)=(cksd-cktd)*DD
        E1(2,2,U)=(sksd*cktd/s1+t*cksd*sktd)*DD
            E1(2,3,U)=-E1(1,4,U)
            E1(2,4,U)=(-sksd/s1-t*sktd)*DD
            E1(3,3,U)=E1(1,1,U)
            E1(3,4,U)=-E1(1,2,U)
        E1(4,4,U)=E1(2,2,U)
        E1(2,1,U)=E1(1,2,U); E1(3,1,U)=E1(1,3,U); E1(4,1,U)=E1(1,4,U)
        E1(3,2,U)=E1(2,3,U); E1(4,2,U)=E1(2,4,U)
        E1(4,3,U)=E1(3,4,U)
        IF(U<=N1+1)THEN
        call GAUSS(E1(:,:,U),IIPSV,E1ni(:,:,U),4,4)
        EE=(0.0,0.0)
        et=exp(AII*kXY*t*d(U)); es=exp(AII*kXY*s1*d(U))
        EE(1,1)=lx;            EE(1,2)=lx;            EE(1,3)=-mx*t;    EE(1,4)=mx*t
            EE(2,1)=-lx*s1;        EE(2,2)=lx*s1;     EE(2,3)=-mx;      EE(2,4)=-mx
            EE(3,1)=lx*es;         EE(3,2)=lx/es;         EE(3,3)=-mx*t*et; EE(3,4)=mx*t/et
            EE(4,1)=-lx*s1*es; EE(4,2)=lx*s1/es;  EE(4,3)=-mx*et;       EE(4,4)=-mx/et
        call GAUSS(EE,IIPSV,E1_ni(:,:,U),4,4)
        et=exp(AII*kXY*t*Z(U)); es=exp(AII*kXY*s1*Z(U))
        E13(1,1,U)=lx*es;          E13(1,2,U)=lx/es;      E13(1,3,U)=-mx*t*et;      E13(1,4,U)=mx*t/et 
        E13(2,1,U)=-lx*s1*es;  E13(2,2,U)=lx*s1/es;       E13(2,3,U)=-mx*et;        E13(2,4,U)=-mx/et
        
        FU=-AII*kXY*LX*(LMD(U)+2*G(u)+LMD(U)*S1*S1);  E14(1,1,U)=FU*ES;         E14(1,2,U)=FU/ES
        FU=2*AII*kXY*mx*t*G(u);                       E14(1,3,U)=FU*ET;         E14(1,4,U)=-FU/ET
        FU=-AII*kXY*LX*(LMD(U)+LMD(U)*S1*S1);         E14(2,1,U)=FU*ES;         E14(2,2,U)=FU/ES
        FU=AII*KXY*LX*(1.0-T*T)*G(u);                 E14(3,1,U)=FU*ES;         E14(3,2,U)=FU/ES
        FU=-2*AII*kXY*mx*t*G(u);                      E14(3,3,U)=FU*ET;         E14(3,4,U)=-FU/ET
        FU=2*AII*kXY*Lx*S1*G(u);                      E14(4,1,U)=FU*ES;         E14(4,2,U)=-FU/ES
        FU=AII*kXY*MX*(1.0-T*T)*G(u);                 E14(4,3,U)=FU*ET;         E14(4,4,U)=FU/ET
        END IF
        
        kXYt=sqrt(w**2/cs(U)**2-kXY**2) 
        E2(1,1,U)=kXYt*G(U)/sin(kXYt*d(U))*cos(kXYt*d(U))
        E2(1,2,U)=-kXYt*G(U)/sin(kXYt*d(U))
        E2(2,1,U)=-kXYt*G(U)/sin(kXYt*d(U))
        E2(2,2,U)=kXYt*G(U)/sin(kXYt*d(U))*cos(kXYt*d(U))
          enddo
          mx=cs(N+1)/w*kXY; t=-AII*sqrt(1-1/mx**2);  t=abs(dble(t))-AII*abs(dimag(t))
      lx=cp(N+1)/w*kXY; s1=-AII*sqrt(1-1/lx**2); s1=abs(dble(s1))-AII*abs(dimag(s1))
      a1=(1+t*t)/(1+s1*t)
      E1(1,1,N+1)=kXY*G(N+1)*AII*s1*a1
      E1(1,2,N+1)=kXY*G(N+1)*(2-a1)
      E1(2,2,N+1)=kXY*G(N+1)*AII*t*a1
      
      t=sqrt(1/mx**2-1)  
          E2(1,1,N+1)=AII*kXY*t*G(N+1)
      
      K1(1,1)=E1(1,1,1); K1(1,2)=E1(1,2,1); K1(2,1)=E1(2,2,1)
      do i=1,N
        K1(2*i+1,1)=E1(3,3,i)+E1(1,1,i+1)
            K1(2*i+1,2)=E1(3,4,i)+E1(1,2,i+1)
            K1(2*i+2,1)=E1(4,4,i)+E1(2,2,i+1)
        K1(2*i-1,3)=E1(1,3,i)
            K1(2*i-1,4)=E1(1,4,i)
            K1(2*i,2)  =E1(2,3,i)
            K1(2*i,3)  =E1(2,4,i)
      enddo
      
      K2(1,2)=E2(1,1,1)
      do i=2,N+1 
        K2(i,2)=E2(2,2,i-1)+E2(1,1,i)
      enddo
      do i=1,N
            K2(i,3)=E2(1,2,i)
            K2(i+1,1)=E2(1,2,i)
      enddo
  end subroutine

subroutine DKFREE(kx,ky)
        use quanju      
        implicit none
        integer(long) U,I
        complex(double) kx,ky,lx,mx,ly,my,lz,mz,kpz,ksz,S1,S2,S3,S4,S5,fu,LMD2G,mx1,my1,mxmz,mymz,E1F(6,6),E2F(6,6)
          E1F=(0,0);E2F=(0,0);K=(0,0);E1_niF=(0,0);E3=(0,0);E4=(0,0);EHF=(0,0)
          do U=1,N
        lx=CP(U)*kx/w; ly=CP(U)*ky/w; lz=sqrt(1-lx**2-ly**2); lz=abs(dble(lz))-AII*abs(dimag(lz))
            mx=CS(U)*kx/w; my=CS(U)*ky/w; mz=sqrt(1-mx**2-my**2); mz=abs(dble(mz))-AII*abs(dimag(mz))                 
            kpz=w*lz/CP(U); S1=exp(AII*kpz*d(U)); S2=1/S1
            ksz=w*mz/CS(U); S3=exp(AII*ksz*d(U)); S4=1/S3
        LMD2G=LMD(U)+2*G(U); S5=sqrt(mx**2+my**2); mxmz=mx*mz/S5; mymz=my*mz/S5; mx1=mx/S5; my1=my/S5  
        E1F(1,1)=lx;         E1F(1,2)=lx;        E1F(1,3)=-mxmz;      E1F(1,4)=mxmz;       E1F(1,5)=-my1;      E1F(1,6)=-my1
            E1F(2,1)=ly;                E1F(2,2)=ly;        E1F(2,3)=-mymz;      E1F(2,4)=mymz;       E1F(2,5)=mx1; &
  & E1F(2,6)=mx1
            E1F(3,1)=-AII*lz;   E1F(3,2)=AII*lz;    E1F(3,3)=-AII*S5;    E1F(3,4)=-AII*S5;    E1F(3,5)=(0d0,0d0); &
  & E1F(3,6)=(0d0,0d0)
        E1F(4,1)=lx*S1;      E1F(4,2)=lx*S2;     E1F(4,3)=-mxmz*S3;   E1F(4,4)=mxmz*S4;    E1F(4,5)=-my1*S3; &
  & E1F(4,6)=-my1*S4
            E1F(5,1)=ly*S1;      E1F(5,2)=ly*S2;     E1F(5,3)=-mymz*S3;   E1F(5,4)=mymz*S4;    E1F(5,5)=mx1*S3; &
  & E1F(5,6)=mx1*S4
            E1F(6,1)=-AII*lz*S1; E1F(6,2)=AII*lz*S2; E1F(6,3)=-AII*S5*S3; E1F(6,4)=-AII*S5*S4; E1F(6,5)=(0d0,0d0); E1F(6, &
  & 6)=(0d0,0d0)
        E2F(1,1)=-AII*(lx*kpz+lz*kx)*G(U);              E2F(1,2)=-E2F(1,1)
        E2F(1,3)=AII*(mxmz*ksz-S5*kx)*G(U);             E2F(1,4)=E2F(1,3)
        E2F(1,5)=AII*my1*ksz*G(U);                      E2F(1,6)=-E2F(1,5)
        E2F(2,1)=-AII*(ly*kpz+lz*ky)*G(U);              E2F(2,2)=-E2F(2,1)
        E2F(2,3)=AII*(mymz*ksz-S5*ky)*G(U);             E2F(2,4)=E2F(2,3)
        E2F(2,5)=-AII*mx1*ksz*G(U);                     E2F(2,6)=-E2F(2,5)
        E2F(3,1)=-(lx*kx+ly*ky)*lmd(U)-LMD2G*lz*kpz;    E2F(3,2)=E2F(3,1)
        E2F(3,3)=lmd(U)*(mxmz*kx+mymz*ky)-Lmd2G*S5*ksz; E2F(3,4)=-E2F(3,3)
        E2F(3,5)=(my1*kx-mx1*ky)*lmd(U);                E2F(3,6)=E2F(3,5)
        E2F(4,1)=-E2F(1,1)*S1; E2F(4,2)=-E2F(1,2)*S2; E2F(4,3)=-E2F(1,3)*S3
        E2F(4,4)=-E2F(1,4)*S4; E2F(4,5)=-E2F(1,5)*S3; E2F(4,6)=-E2F(1,6)*S4
        E2F(5,1)=-E2F(2,1)*S1; E2F(5,2)=-E2F(2,2)*S2; E2F(5,3)=-E2F(2,3)*S3
        E2F(5,4)=-E2F(2,4)*S4; E2F(5,5)=-E2F(2,5)*S3; E2F(5,6)=-E2F(2,6)*S4
        E2F(6,1)=-E2F(3,1)*S1; E2F(6,2)=-E2F(3,2)*S2; E2F(6,3)=-E2F(3,3)*S3
        E2F(6,4)=-E2F(3,4)*S4; E2F(6,5)=-E2F(3,5)*S3; E2F(6,6)=-E2F(3,6)*S4
        call Gauss(E1F,II,E1_niF(:,:,U),6,6)
        call pxp(E2F,E1_niF(:,:,U),E(:,:,U),6,6,6)
        
        if(U<=N1)then
          S1=exp(AII*kpz*z(U)); S2=1/S1; S3=exp(AII*ksz*z(U)); S4=1/S3
          E3(1,1,U)=lx*S1;  E3(1,2,U)=lx*S2; E3(1,3,U)=-mxmz*S3; E3(1,4,U)=mxmz*S4; E3(1,5,U)=-my1*S3; E3(1,6,U)=-my1*S4
              E3(2,1,U)=ly*S1;  E3(2,2,U)=ly*S2; E3(2,3,U)=-mymz*S3; E3(2,4,U)=mymz*S4; E3(2,5,U)=mx1*S3;  E3(2,6,U)=mx1*S4
          E3(3,1,U)=-lz*S1; E3(3,2,U)=lz*S2; E3(3,3,U)=-S5*S3;   E3(3,4,U)=-S5*S4
          fu=-AII*(LMD2G*lx*kx+LMD(U)*ly*ky+LMD(U)*lz*kpz); E4(1,1,U)=S1*fu;  E4(1,2,U)=S2*fu      
          fu=AII*(LMD(U)*(ksz*S5-mymz*ky)-LMD2G*mxmz*kx);   E4(1,3,U)=-S3*fu; E4(1,4,U)=S4*fu
              fu=AII*(LMD2G*my1*kx-LMD(U)*mx1*ky);              E4(1,5,U)=S3*fu;  E4(1,6,U)=S4*fu
              fu=-AII*(LMD(U)*(lx*kx+lz*kpz)+LMD2G*ly*ky);      E4(2,1,U)=S1*fu;  E4(2,2,U)=S2*fu
              fu=AII*(LMD(U)*(ksz*S5-mxmz*kx)-LMD2G*mymz*ky);   E4(2,3,U)=-S3*fu; E4(2,4,U)=S4*fu
              fu=AII*(LMD(U)*my1*kx-LMD2G*mx1*ky);              E4(2,5,U)=S3*fu;  E4(2,6,U)=S4*fu
              fu=-AII*(LMD(U)*(ly*ky+lx*kx)+LMD2G*lz*kpz);          E4(3,1,U)=S1*fu;  E4(3,2,U)=S2*fu
              fu=AII*(LMD2G*ksz*S5-LMD(U)*(mxmz*kx+mymz*ky));   E4(3,3,U)=-S3*fu; E4(3,4,U)=S4*fu
              fu=AII*LMD(U)*(my1*kx-mx1*ky);                    E4(3,5,U)=S3*fu;  E4(3,6,U)=S4*fu
              fu=-AII*G(U)*(ly*kx+lx*ky);                           E4(4,1,U)=S1*fu;  E4(4,2,U)=S2*fu
              fu=AII*G(U)*mz*(mx1*ky+my1*kx);                   E4(4,3,U)=S3*fu;  E4(4,4,U)=-S4*fu
              fu=-AII*G(U)*(mx1*kx-my1*ky);                     E4(4,5,U)=S3*fu;  E4(4,6,U)=S4*fu
              fu=AII*G(U)*(lz*kx+lx*kpz);                           E4(5,1,U)=S1*fu;  E4(5,2,U)=-S2*fu
              fu=AII*G(U)*(kx*S5-mxmz*ksz);                     E4(5,3,U)=S3*fu;  E4(5,4,U)=S4*fu
              fu=AII*G(U)*my1*ksz;                              E4(5,5,U)=-S3*fu; E4(5,6,U)=S4*fu
              fu=AII*G(U)*(lz*ky+ly*kpz);                           E4(6,1,U)=S1*fu;  E4(6,2,U)=-S2*fu
              fu=AII*G(U)*(ky*S5-mymz*ksz);                     E4(6,3,U)=S3*fu;  E4(6,4,U)=S4*fu
              fu=AII*G(U)*mx1*ksz;                              E4(6,5,U)=S3*fu;  E4(6,6,U)=-S4*fu       
        endif 
        if(U==N1+1)then
            S1=exp(AII*kpz*0.0); S2=1/S1; S3=exp(AII*ksz*0.0); S4=1/S3
            E3HE1F(1,1)=lx*S1;  E3HE1F(1,2)=lx*S2; E3HE1F(1,3)=-mxmz*S3; E3HE1F(1,4)=mxmz*S4; E3HE1F(1,5)=-my1*S3; &
  & E3HE1F(1,6)=-my1*S4
                E3HE1F(2,1)=ly*S1;  E3HE1F(2,2)=ly*S2; E3HE1F(2,3)=-mymz*S3; E3HE1F(2,4)=mymz*S4; E3HE1F(2,5)=mx1*S3; &
  & E3HE1F(2,6)=mx1*S4
            E3HE1F(3,1)=-lz*S1; E3HE1F(3,2)=lz*S2; E3HE1F(3,3)=-S5*S3;   E3HE1F(3,4)=-S5*S4
            fu=-AII*(LMD2G*lx*kx+LMD(U)*ly*ky+LMD(U)*lz*kpz); E4HE1F(1,1)=S1*fu;  E4HE1F(1,2)=S2*fu      
            fu=AII*(LMD(U)*(ksz*S5-mymz*ky)-LMD2G*mxmz*kx);   E4HE1F(1,3)=-S3*fu; E4HE1F(1,4)=S4*fu
                fu=AII*(LMD2G*my1*kx-LMD(U)*mx1*ky);              E4HE1F(1,5)=S3*fu;  E4HE1F(1,6)=S4*fu
                fu=-AII*(LMD(U)*(lx*kx+lz*kpz)+LMD2G*ly*ky);      E4HE1F(2,1)=S1*fu;  E4HE1F(2,2)=S2*fu
                fu=AII*(LMD(U)*(ksz*S5-mxmz*kx)-LMD2G*mymz*ky);   E4HE1F(2,3)=-S3*fu; E4HE1F(2,4)=S4*fu
                fu=AII*(LMD(U)*my1*kx-LMD2G*mx1*ky);              E4HE1F(2,5)=S3*fu;  E4HE1F(2,6)=S4*fu
                fu=-AII*(LMD(U)*(ly*ky+lx*kx)+LMD2G*lz*kpz);      E4HE1F(3,1)=S1*fu;  E4HE1F(3,2)=S2*fu
                fu=AII*(LMD2G*ksz*S5-LMD(U)*(mxmz*kx+mymz*ky));   E4HE1F(3,3)=-S3*fu; E4HE1F(3,4)=S4*fu
                fu=AII*LMD(U)*(my1*kx-mx1*ky);                    E4HE1F(3,5)=S3*fu;  E4HE1F(3,6)=S4*fu
                fu=-AII*G(U)*(ly*kx+lx*ky);                           E4HE1F(4,1)=S1*fu;  E4HE1F(4,2)=S2*fu
                fu=AII*G(U)*mz*(mx1*ky+my1*kx);                   E4HE1F(4,3)=S3*fu;  E4HE1F(4,4)=-S4*fu
                fu=-AII*G(U)*(mx1*kx-my1*ky);                     E4HE1F(4,5)=S3*fu;  E4HE1F(4,6)=S4*fu
                fu=AII*G(U)*(lz*kx+lx*kpz);                           E4HE1F(5,1)=S1*fu;  E4HE1F(5,2)=-S2*fu
                fu=AII*G(U)*(kx*S5-mxmz*ksz);                     E4HE1F(5,3)=S3*fu;  E4HE1F(5,4)=S4*fu
                fu=AII*G(U)*my1*ksz;                              E4HE1F(5,5)=-S3*fu; E4HE1F(5,6)=S4*fu
                fu=AII*G(U)*(lz*ky+ly*kpz);                           E4HE1F(6,1)=S1*fu;  E4HE1F(6,2)=-S2*fu
                fu=AII*G(U)*(ky*S5-mymz*ksz);                     E4HE1F(6,3)=S3*fu;  E4HE1F(6,4)=S4*fu
                fu=AII*G(U)*mx1*ksz;                              E4HE1F(6,5)=S3*fu;  E4HE1F(6,6)=-S4*fu        
          END IF         
          enddo
          lx=cp(N+1)*kx/w; ly=cp(N+1)*ky/w; lz=sqrt(1-lx**2-ly**2); lz=abs(dble(lz))-AII*abs(dimag(lz)); kpz=w*lz/cp(N+1)
          mx=cs(N+1)*kx/w; my=cs(N+1)*ky/w; mz=sqrt(1-mx**2-my**2); mz=abs(dble(mz))-AII*abs(dimag(mz)); ksz=w*mz/cs(N+1)
      LMD2G=LMD(N+1)+2*G(N+1); S5=lx*mx+ly*my+lz*mz
      Ehf(1,1)=AII*(lx*kpz*mx+lz*mz*ksz+my*ksz*ly)*G(N+1)/S5
      Ehf(1,2)=AII*(kpz-ksz)*lx*G(N+1)*my/S5
      Ehf(1,3)=(kx*S5+mz*lx*(kpz-ksz))*G(N+1)/S5
      Ehf(2,2)=AII*(ksz*lx*mx+my*ly*kpz+lz*mz*ksz)*G(N+1)/S5
      Ehf(2,3)=(ky*S5+mz*ly*(kpz-ksz))*G(N+1)/S5
      Ehf(3,3)=AII*(ksz*(lx*mx+my*ly)+mz*lz*kpz)*Lmd2G/S5
      Ehf(2,1)=Ehf(1,2)
          Ehf(3,1)=Ehf(1,3)
          Ehf(3,2)=Ehf(2,3)
          
          K(1,1:6)=E(1,1:6,1)
      K(2,1:5)=E(2,2:6,1)
          K(3,1:4)=E(3,3:6,1)
      do i=2,N
        K(3*i-2,1)=E(4,4,i-1)+E(1,1,i)
                K(3*i-2,2)=E(4,5,i-1)+E(1,2,i)
                K(3*i-2,3)=E(4,6,i-1)+E(1,3,i)
                K(3*i-2,4:6)=E(1,4:6,i)
                K(3*i-1,1)=E(5,5,i-1)+E(2,2,i)
                K(3*i-1,2)=E(5,6,i-1)+E(2,3,i)
            K(3*i-1,3:5)=E(2,4:6,i)
                K(3*i,1)=E(6,6,i-1)+E(3,3,i)
            K(3*i,2:4)=E(3,4:6,i)
          enddo   
          K(3*N+1,1:3)=E(4,4:6,N)+Ehf(1,1:3)
          K(3*N+2,1:2)=E(5,5:6,N)+Ehf(2,2:3)
          K(3*N+3,1)=E(6,6,N)+Ehf(3,3)
      
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      SS=(0D0,0D0)
      SS(1,1)=K(1,1);SS(1,2)=K(1,2);SS(1,3)=K(1,3);SS(2,1)=K(1,2);SS(2,2)=K(2,1);SS(2,3)=K(2,2);SS(3,1)=K(1,3); &
  & SS(3,2)=K(2,2);SS(3,3)=K(3,1)
      DO I=1,N
        SS(3*I-2,3*I+1)=K(3*I-2,4);SS(3*I-2,3*I+2)=K(3*I-2,5);SS(3*I-2,3*I+3)=K(3*I-2,6)
        SS(3*I-1,3*I+1)=K(3*I-1,3);SS(3*I-1,3*I+2)=K(3*I-1,4);SS(3*I-1,3*I+3)=K(3*I-1,5)
        SS(3*I,3*I+1)=K(3*I,2);SS(3*I,3*I+2)=K(3*I,3);SS(3*I,3*I+3)=K(3*I,4)
        
        SS(3*I+1,3*I-2)=K(3*I-2,4);SS(3*I+1,3*I-1)=K(3*I-1,3);SS(3*I+1,3*I)=K(3*I,2)
        SS(3*I+2,3*I-2)=K(3*I-2,5);SS(3*I+2,3*I-1)=K(3*I-1,4);SS(3*I+2,3*I)=K(3*I,3)
        SS(3*I+3,3*I-2)=K(3*I-2,6);SS(3*I+3,3*I-1)=K(3*I-1,5);SS(3*I+3,3*I)=K(3*I,4)
        
        SS(3*I+1,3*I+1)=K(3*I+1,1);SS(3*I+1,3*I+2)=K(3*I+1,2);SS(3*I+1,3*I+3)=K(3*I+1,3)
        SS(3*I+2,3*I+1)=K(3*I+1,2);SS(3*I+2,3*I+2)=K(3*I+2,1);SS(3*I+2,3*I+3)=K(3*I+2,2)
        SS(3*I+3,3*I+1)=K(3*I+1,3);SS(3*I+3,3*I+2)=K(3*I+2,2);SS(3*I+3,3*I+3)=K(3*I+3,1)
      END DO
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
  end subroutine

