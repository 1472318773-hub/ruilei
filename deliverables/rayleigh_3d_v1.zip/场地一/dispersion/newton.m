function x2=newton(f,x0,x1,q)
n=0;
x2=x1-feval(f,x1)*(x1-x0)/(feval(f,x1)-feval(f,x0));
n=n+1;
while((abs(x2-x1)>=q)&(n<=1000))
    x0=x1;
    x1=x2;
    x2=x1-feval(f,x1)*(x1-x0)/(feval(f,x1)-feval(f,x0));
    n=n+1;
end

