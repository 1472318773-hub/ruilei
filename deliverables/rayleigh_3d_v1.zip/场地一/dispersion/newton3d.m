function x2=newton3d(f,x0,x1,q)


maxit = 50;
ftol = 1e-5;
maxstep = 50;

f0 = feval(f,x0);
f1 = feval(f,x1);

if abs(f0) < ftol
    x2 = x0;
    return;
end
if abs(f1) < ftol
    x2 = x1;
    return;
end

x2 = x1;
for n = 1:maxit
    den = f1 - f0;
    if ~isfinite(real(den)) || ~isfinite(imag(den)) || abs(den) < eps*max(1,abs(f0)+abs(f1))
        return;
    end

    dx = -f1*(x1-x0)/den;
    if abs(dx) > maxstep
        dx = dx/abs(dx)*maxstep;
    end
    xt = x1 + dx;

    if ~isfinite(real(xt)) || ~isfinite(imag(xt))
        x2 = x1;
        return;
    end

    f2 = feval(f,xt);
    if ~isfinite(real(f2)) || ~isfinite(imag(f2))
        x2 = x1;
        return;
    end

    
    if abs(f2) > 10*abs(f1)
        x2 = x1;
        return;
    end

    x2 = xt;
    if abs(dx) < q || abs(f2) < ftol
        return;
    end

    x0 = x1; f0 = f1;
    x1 = x2; f1 = f2;
end
