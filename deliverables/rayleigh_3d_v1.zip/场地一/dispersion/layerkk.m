function h=layerkk(ii,KX,KY)
global W;
global CS;   % 存的是速度平方(含阻尼): CS(ii)=CSL^2*(1+2i*ZN)
global CP;
global G;    % 剪切模量 mu
global D;    % 各层厚度

DDD = D(ii);
CS1 = sqrt(CS(ii));            % 横波速度(复)
CP1 = sqrt(CP(ii));            % 纵波速度(复)
MU  = G(ii);                   % mu
LMD = MU*(CP1^2/CS1^2 - 2.0);  % lambda
LMD2G = LMD + 2.0*MU;          % lambda + 2 mu


LX = CP1*KX/W;  LY = CP1*KY/W;  LZ = sqrt(1.0 - LX^2 - LY^2);
LZ = abs(real(LZ)) - 1i*abs(imag(LZ));     
MX = CS1*KX/W;  MY = CS1*KY/W;  MZ = sqrt(1.0 - MX^2 - MY^2);
MZ = abs(real(MZ)) - 1i*abs(imag(MZ));

KPZ = W*LZ/CP1;  S1 = exp(1i*KPZ*DDD);  S2 = 1/S1;  
KSZ = W*MZ/CS1;  S3 = exp(1i*KSZ*DDD);  S4 = 1/S3;   

S5   = sqrt(MX^2 + MY^2);     
MXMZ = MX*MZ/S5;  MYMZ = MY*MZ/S5;  MX1 = MX/S5;  MY1 = MY/S5;


E1F = zeros(6,6);
E1F(1,1)=LX;        E1F(1,2)=LX;        E1F(1,3)=-MXMZ;     E1F(1,4)=MXMZ;      E1F(1,5)=-MY1;      E1F(1,6)=-MY1;
E1F(2,1)=LY;        E1F(2,2)=LY;        E1F(2,3)=-MYMZ;     E1F(2,4)=MYMZ;      E1F(2,5)=MX1;       E1F(2,6)=MX1;
E1F(3,1)=-1i*LZ;    E1F(3,2)=1i*LZ;     E1F(3,3)=-1i*S5;    E1F(3,4)=-1i*S5;    E1F(3,5)=0;         E1F(3,6)=0;
E1F(4,1)=LX*S1;     E1F(4,2)=LX*S2;     E1F(4,3)=-MXMZ*S3;  E1F(4,4)=MXMZ*S4;   E1F(4,5)=-MY1*S3;   E1F(4,6)=-MY1*S4;
E1F(5,1)=LY*S1;     E1F(5,2)=LY*S2;     E1F(5,3)=-MYMZ*S3;  E1F(5,4)=MYMZ*S4;   E1F(5,5)=MX1*S3;    E1F(5,6)=MX1*S4;
E1F(6,1)=-1i*LZ*S1; E1F(6,2)=1i*LZ*S2;  E1F(6,3)=-1i*S5*S3; E1F(6,4)=-1i*S5*S4; E1F(6,5)=0;         E1F(6,6)=0;


E2F = zeros(6,6);
E2F(1,1)=-1i*(LX*KPZ+LZ*KX)*MU;            E2F(1,2)=-E2F(1,1);
E2F(1,3)=1i*(MXMZ*KSZ-S5*KX)*MU;           E2F(1,4)=E2F(1,3);
E2F(1,5)=1i*MY1*KSZ*MU;                    E2F(1,6)=-E2F(1,5);
E2F(2,1)=-1i*(LY*KPZ+LZ*KY)*MU;            E2F(2,2)=-E2F(2,1);
E2F(2,3)=1i*(MYMZ*KSZ-S5*KY)*MU;           E2F(2,4)=E2F(2,3);
E2F(2,5)=-1i*MX1*KSZ*MU;                   E2F(2,6)=-E2F(2,5);
E2F(3,1)=-(LX*KX+LY*KY)*LMD-LMD2G*LZ*KPZ;  E2F(3,2)=E2F(3,1);
E2F(3,3)=LMD*(MXMZ*KX+MYMZ*KY)-LMD2G*S5*KSZ; E2F(3,4)=-E2F(3,3);
E2F(3,5)=(MY1*KX-MX1*KY)*LMD;              E2F(3,6)=E2F(3,5);
E2F(4,1)=-E2F(1,1)*S1; E2F(4,2)=-E2F(1,2)*S2; E2F(4,3)=-E2F(1,3)*S3;
E2F(4,4)=-E2F(1,4)*S4; E2F(4,5)=-E2F(1,5)*S3; E2F(4,6)=-E2F(1,6)*S4;
E2F(5,1)=-E2F(2,1)*S1; E2F(5,2)=-E2F(2,2)*S2; E2F(5,3)=-E2F(2,3)*S3;
E2F(5,4)=-E2F(2,4)*S4; E2F(5,5)=-E2F(2,5)*S3; E2F(5,6)=-E2F(2,6)*S4;
E2F(6,1)=-E2F(3,1)*S1; E2F(6,2)=-E2F(3,2)*S2; E2F(6,3)=-E2F(3,3)*S3;
E2F(6,4)=-E2F(3,4)*S4; E2F(6,5)=-E2F(3,5)*S3; E2F(6,6)=-E2F(3,6)*S4;


if rcond(E1F) < 1e-12
    h = E2F * pinv(E1F);
else
    h = E2F / E1F;
end
