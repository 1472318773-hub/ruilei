


 subroutine Solv(N,NB,KK,node,uvw,NL)
   implicit none
   integer(4) i,j,M,L,N,NB,K,K1,NL
   complex(8) A(N,6),node(N,NL),T,KK(N,6),uvw(N+10,NL)
         do i=1,N
           do j=1,6
             A(i,j)=KK(i,j)
       enddo
           uvw(i,:)=node(i,:)
         enddo
     do M=1,N
           i=M
           do 20 L=2,NB
             i=i+1
             iF((ABS(A(M,L)).LE.1.0d-300)) GOTO 20
             T=A(M,L)/A(M,1)
             j=0
             do K=L,NB
               j=j+1
               A(i,j)=A(i,j)-T*A(M,K)
         enddo
         A(M,L)=T
             uvw(i,:)=uvw(i,:)-T*uvw(M,:)
  20   CONTiNUE
       uvw(M,:)=uvw(M,:)/A(M,1)
     enddo   
         uvw(N+1:N+10,:)=(0d0,0d0)
         do K1=2,N
           i=N-K1+1
           do K=2,NB
             j=i+K-1
             uvw(i,:)=uvw(i,:)-A(i,K)*uvw(j,:)
       enddo
     enddo
 end subroutine



 subroutine pxp(A,B,C,M,N,K)
   implicit none
   integer(4) M,N,K,i,j,l
   complex(8) A(M,N),B(N,K),C(M,K)
     C=(0d0,0d0)
     do i=1,M
       do j=1,K
         do l=1,N
           C(i,j)=C(i,j)+A(i,l)*B(l,j)
         enddo
       enddo
     enddo
 end subroutine



 

 subroutine tx(A,B,C,K,M,N)
   implicit none
   integer(4) M,N,K,i,j,l
   complex(8) A(K,M),B(K,N),C(M,N)  
     C=(0d0,0d0)
     do i=1,M
       do j=1,N    
             do l=1,K
               C(i,j)=C(i,j)+A(l,i)*B(l,j)
             enddo
           enddo
     enddo
 end subroutine
 
  

SUBROUTINE  solvS(N,NB,S,Q,v,NL)
        implicit none
        integer(4) i,j,M,K,L,K1,N,NB,NL
        complex(8)  A(N,NB),S(N,NB),Q(N,NL),v(N+10,NL),T
      A=S; v(1:N,:)=Q; v(N+1:N+10,:)=(0d0,0d0)
          DO M=1,N
            I=M
            DO 20 L=2,NB
              I=I+1
              IF((ABS(A(M,L)).LE.1.0E-20)) GOTO 20
              T=A(M,L)/A(M,1)
              J=0
              DO K=L,NB
                J=J+1
                A(I,J)=A(I,J)-T*A(M,K)
          enddo
          A(M,L)=T
              v(I,:)=v(I,:)-T*v(M,:)
   20   continue
        v(M,:)=v(M,:)/A(M,1)
      enddo
          DO K1=2,N
            i=N-K1+1
            DO K=2,NB
              j=i+K-1
              v(i,:)=v(i,:)-A(i,K)*v(j,:)
        enddo
      enddo
 end subroutine
 SUBROUTINE SOLVSH(N,NB,S,Q,v,NL)
  implicit none
  integer(4) M1,I,J,NL,N,NB
  complex(8) S1(N,3),Q(N,NL),v(N+10,NL),S(N,3)
         
  do i=1,N
        do j=1,3
          S1(I,J)=S(I,J)
        enddo
  enddo
  v(1:N,:)=Q; v(N+1:N+10,:)=(0d0,0d0)
  DO I=2,N
    S1(I,2)=S1(I,2)-S1(I,1)/S1(I-1,2)*S1(I-1,3)
    v(I,:)=v(I,:)-S1(I,1)/S1(I-1,2)*v(I-1,:)
  enddo
  v(N,:)=v(N,:)/S1(N,2)
  M1=N
  DO I=1,N-1
    M1=M1-1
    v(M1,:)=(v(M1,:)-S1(M1,3)*v(M1+1,:))/S1(M1,2)
  enddo
END subroutine
