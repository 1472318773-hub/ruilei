 
subroutine GreenUNIT(kxy,U,UWUNIT,TXYZUNIT,VVUNIT,tYzUNIT,tYXUNIT)
        use quanju
    implicit none
        integer(long) U,i,j,L,I1
        complex(double) kx,ky,Q1,Q2,P1,P2,E11,E22
        complex(double) KXY,LMDG,LMD2G 
    complex(double) lx,mx,s1,ks,kt,T
    complex(double) nodeUNIT1(2*(N+1),4),nodeUNIT2(N+1,2),vUNIT1(2*(N+1)+10,4),VUNIT2(N+1+10,2),UWUNIT(2,4,N1+1), &
  & TXYZUNIT(4,4,N1+1),YUNIT(4,4),ABUNIT(4,4)  
    complex(double) VVUNIT(2,N1+1),tYzUNIT(2,N1+1),tYXUNIT(2,N1+1)
      
      nodeUNIT1=(0.0,0.0);nodeUNIT2=(0.0,0.0)
      
      nodeUNIT1(2*U-1,1)=(1.0D0,1.0D0);nodeUNIT1(2*U+1,1)=(1.0D0,1.0D0)
          nodeUNIT1(2*U,2)=(1.0D0,1.0D0);nodeUNIT1(2*U+2,2)=(1.0D0,1.0D0)
          nodeUNIT1(2*U-1,3)=(1.0D0,1.0D0);nodeUNIT1(2*U+1,3)=(-1.0D0,-1.0D0)
          nodeUNIT1(2*U,4)=(1.0D0,1.0D0);nodeUNIT1(2*U+2,4)=(-1.0D0,-1.0D0)
          
          UWUNIT=(0.0,0.0);TXYZUNIT=(0.0,0.0);VVUNIT=(0.0,0.0);TYZUNIT=(0.0,0.0);TYXUNIT=(0.0,0.0)
          
          CALL SOLVS(2*(N+1),4,K1,nodeUNIT1,VUNIT1,4)
          do L=1,N1
      YUNIT(1,:)=vUNIT1(2*L-1,:); YUNIT(2,:)=-AII*vUNIT1(2*L,:); YUNIT(3,:)=vUNIT1(2*L+1,:); YUNIT(4,:)=-AII*vUNIT1(2*L+2,:)
      call pxp(E1_ni(:,:,L),YUNIT,ABUNIT,4,4,4)
          CALL PXP(E13(:,:,L),ABUNIT,UWUNIT(:,:,L),2,4,4)
          CALL PXP(E14(:,:,L),ABUNIT,TXYZUNIT(:,:,L),4,4,4)
      END DO
      
      NODEUNIT2(U,1)=(1.0D0,1.0D0);NODEUNIT2(U+1,1)=(1.0D0,1.0D0)
          NODEUNIT2(U,2)=(1.0D0,1.0D0);NODEUNIT2(U+1,2)=(-1.0D0,-1.0D0)
          
          CALL SOLVSH(N+1,2,K2,nodeUNIT2,VUNIT2,2)
          DO L=1,N1
            mx=cs(L)*kXY/w;  t=sqrt(1/mx**2-1);  kt=kXY*t         
        VVUNIT(:,L)=(VUNIT2(L+1,:)*sin(kt*d(L)/2)+VUNIT2(L,:)*sin(kt*d(L)/2))/sin(kt*d(L))
        TYZUNIT(:,L)=kt*G(L)*(vUNIT2(L+1,:)*cos(kt*d(L)/2)-vUNIT2(L,:)*cos(kt*d(L)/2))/sin(kt*d(L))
        TYXUNIT(:,L)=(-AII*kXY*G(L))*VVUNIT(:,L) 
          END DO 
          
      YUNIT(1,:)=vUNIT1(2*(N1+1)-1,:); YUNIT(2,:)=-AII*vUNIT1(2*(N1+1),:); YUNIT(3,:)=vUNIT1(2*(N1+1)+1,:); &
  & YUNIT(4,:)=-AII*vUNIT1(2*(N1+1)+2,:)
      call pxp(E1_ni(:,:,(N1+1)),YUNIT,ABUNIT,4,4,4)
      CALL PXP(E13(:,:,(N1+1)),ABUNIT,UWUNIT(:,:,(N1+1)),2,4,4)
      CALL PXP(E14(:,:,(N1+1)),ABUNIT,TXYZUNIT(:,:,(N1+1)),4,4,4)
      
      mx=cs(N1+1)*kXY/w;  t=sqrt(1/mx**2-1);  kt=kXY*t    
      VVUNIT(:,N1+1)=vUNIT2(N1+1,:)
      TYZUNIT(:,N1+1)=kt*G(N1+1)*(vUNIT2(N1+1+1,:)*cos(kt*0.0)-vUNIT2(N1+1,:)*cos(kt*d(N1+1)))/sin(kt*d(N1+1))
      TYXUNIT(:,N1+1)=(-AII*kXY*G(N1+1))*VVUNIT(:,N1+1)  
end subroutine

subroutine GreenbottomUNIT(kxy,UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
        use quanju
    implicit none
        integer(long) L
        complex(double) KXY,nodeUNIT1(2*(N+1),2),nodeUNIT2(N+1)
        complex(double) vUNIT1(2*(N+1)+10,2),vUNIT2(N+1+10)   
    complex(double) ABUNIT(4,2),YUNIT(4,2),mx,kt,T
    complex(double) UWBUNIT(2,2,N1+1),TXYZBUNIT(4,2,N1+1),TYXBUNIT(N1+1),TYZBUNIT(N1+1),VVBUNIT(N1+1)
             
          nodeUNIT1=(0d0,0d0);nodeUNIT2=(0d0,0d0);VVBUNIT=(0,0)
          nodeUNIT1(2*N1+1,1)=(1.0D0,1.0D0);nodeUNIT1(2*N1+2,2)=(1.0D0,1.0D0)
      CALL SOLVS(2*(N+1),4,K1,nodeUNIT1,VUNIT1,2)
      UWBUNIT=(0.0,0.0);TXYZBUNIT=(0.0,0.0)
          do L=1,N1
      YUNIT(1,:)=vUNIT1(2*L-1,:); YUNIT(2,:)=-AII*vUNIT1(2*L,:); YUNIT(3,:)=vUNIT1(2*L+1,:); YUNIT(4,:)=-AII*vUNIT1(2*L+2,:)
      call pxp(E1_ni(:,:,L),YUNIT,ABUNIT,4,4,2)
      CALL PXP(E13(:,:,L),ABUNIT,UWBUNIT(:,:,L),2,4,2)
      CALL PXP(E14(:,:,L),ABUNIT,TXYZBUNIT(:,:,L),4,4,2)
      END DO
      
      nodeUNIT2(N1+1)=(1.0D0,1.0D0)
      CALL SOLVSH(N+1,2,K2,nodeUNIT2,VUNIT2,1)
          DO L=1,N1
            mx=cs(L)*kXY/w;  t=sqrt(1/mx**2-1);  kt=kXY*t         
        VVBUNIT(L)=(vUNIT2(L+1)*sin(kt*d(L)/2)+vUNIT2(L)*sin(kt*d(L)/2))/sin(kt*d(L))
        TYZBUNIT(L)=kt*G(L)*(vUNIT2(L+1)*cos(kt*d(L)/2)-vUNIT2(L)*cos(kt*d(L)/2))/sin(kt*d(L))
        TYXBUNIT(L)=(-AII*kXY*G(L))*VVBUNIT(L) 
          END DO 
          
      L=N1+1
      YUNIT(1,:)=vUNIT1(2*L-1,:); YUNIT(2,:)=-AII*vUNIT1(2*L,:); YUNIT(3,:)=vUNIT1(2*L+1,:); YUNIT(4,:)=-AII*vUNIT1(2*L+2,:)
      call pxp(E1_ni(:,:,L),YUNIT,ABUNIT,4,4,2)
      CALL PXP(E13(:,:,L),ABUNIT,UWBUNIT(:,:,L),2,4,2)
      CALL PXP(E14(:,:,L),ABUNIT,TXYZBUNIT(:,:,L),4,4,2)
      
          mx=cs(L)*kXY/w;  t=sqrt(1/mx**2-1);  kt=kXY*t   
      VVBUNIT(L)=vUNIT2(L)
      TYZBUNIT(L)=kt*G(L)*(vUNIT2(L+1)*cos(kt*0.0)-vUNIT2(L)*cos(kt*d(L)))/sin(kt*d(L))
      TYXBUNIT(L)=(-AII*kXY*G(L))*VVBUNIT(L) 
end subroutine


subroutine GreenUNITTON(kx,ky,KXY,U,length,xmf,ymf,T1,T2,T3,W1,W2,W3,UWUNIT,TXYZUNIT,VVUNIT,tYzUNIT,tYXUNIT)
        use quanju
    implicit none
        integer(long) U,i,j,L,I1
        real(double) length,w_2,kx2,ky2,xmf(N1+NN1,M),ymf(N1+NN1,M),YITA,L33(3,3),COSY,SINY
        complex(double) kx,ky,Q1,Q2,P1,P2,E11,E22,A1(3),A2(3),A3(3),B1(3),B2(3),B3(3),AB(6,3),UP(6,3),UH1(4,3),UH2(2,3), &
  & QP(6,3),QP1(4,3),QP2(2,3),QH1(4,3),QH2(2,3),dis(3,3,N1),str(6,3,N1)
        complex(double) WYTJ(3,3),WYQJ(3,3),YLTJ(6,3),YLQJ(6,3),uvw(3*(N+1)+10,3),node1(2*(N+1),3),node2(N+1,3),exp1,exp2, &
  & as,disHE1(3,3),strHE1(6,3)
        complex(double) KXY,LMDG,LMD2G,P12,P22,A3B3(3),T1(6,N1+NN1,M),T2(6,N1+NN1,M),T3(6,N1+NN1,M),W1(3,N1+NN1,M),W2(3, &
  & N1+NN1,M),W3(3,N1+NN1,M),v1(2*(N+1)+10,3),v2(N+1+10,3)    
    complex(double) uu(3,N1+1),VV(3,N1+1),ww(3,N1+1),txz(3,N1+1),tYz(3,N1+1),tYX(3,N1+1),txx(3,N1+1),tzz(3,N1+1), &
  & ABPSv(4,3),tYY(3,N1+1),Y(4,3),es,et,u1(3),u2(3),wW1(3),wW2(3),lx,mx,s1,ks,kt,T
    complex(double) UW(2,3,N1+1),UWQJ(2,3),TXYZ(4,3,N1+1),TXYZQJ(4,3),XQP(2,3),UH(4,3),XQP2(3)
    complex(double) UWUNIT(2,4,N1+1),TXYZUNIT(4,4,N1+1),VVUNIT(2,N1+1),tYzUNIT(2,N1+1),tYXUNIT(2,N1+1)
      NODE1=(0,0);NODE2=(0,0);uu=(0,0);VV=(0,0);ww=(0,0);txz=(0,0);tYz=(0,0);tYX=(0,0);txx=(0,0);tzz=(0,0); &
  & ABPSv=(0,0);tYY=(0,0);Y=(0,0);u1=(0,0);u2=(0,0);wW1=(0,0);wW2=(0,0)
      
      Q1=exp(AII*ky*y1(U))/ky/AII/(4*PI**2)
      Q2=-exp(-AII*ky*y1(U))/ky/AII/(4*PI**2)
      P1=ky*(y2(U)-y1(U))/d(U)-kx*nz2(U,1)/nx2(U,1)
      P2=ky*(y1(U)-y2(U))/d(U)-kx*nz2(U,1)/nx2(U,1)       
        
          LMDG=Lmd(U)+G(U); LMD2G=Lmd(U)+2*G(U); w_2=w*w; kx2=kx*kx; ky2=ky*ky; P12=P1*P1; P22=P2*P2
      E11=(P(U)*w_2-G(U)*(kx2+ky2+P12))*(P(U)*w_2-LMD2G*(kx2+ky2+P12))
          A1(1)=(LMD2G*(P12+ky2)+G(U)*kx2-P(U)*w_2)/E11
      A1(2)=-kx*ky*LMDG/E11
          A1(3)=P1*kx*LMDG/E11       
          A2(1)=A1(2) 
      A2(2)=(LMD2G*(P12+kx2)+G(U)*ky2-P(U)*w_2)/E11
          A2(3)=P1*ky*LMDG/E11      
          A3(1)=A1(3)
      A3(2)=A2(3)
      A3(3)=(LMD2G*(kx2+ky2)+G(U)*P12-P(U)*w_2)/E11
          E22=(P(U)*w_2-G(U)*(kx2+ky2+P22))*(P(U)*w_2-LMD2G*(kx2+ky2+P22))        
          B1(1)=(LMD2G*(P22+ky2)+G(U)*kx2-P(U)*w_2)/E22
          B1(2)=-kx*ky*LMDG/E22
      B1(3)=kx*P2*LMDG/E22         
      B2(1)=B1(2)
          B2(2)=(LMD2G*(P22+kx2)+G(U)*ky2-P(U)*w_2)/E22
      B2(3)=ky*P2*LMDG/E22
      B3(1)=B1(3)
          B3(2)=B2(3)
          B3(3)=(LMD2G*(kx2+ky2)+G(U)*P22-P(U)*w_2)/E22 
          exp1=EXP(AII*P1*d(U))*Q1
          exp2=EXP(AII*P2*d(U))*Q2     
          UP(1,:)=-(A1(:)*Q1+B1(:)*Q2)
      UP(2,:)=-(A2(:)*Q1+B2(:)*Q2)
          UP(3,:)=-(A3(:)*Q1+B3(:)*Q2)
      UP(4,:)=-(A1(:)*exp1+B1(:)*exp2)
      UP(5,:)=-(A2(:)*exp1+B2(:)*exp2)
      UP(6,:)=-(A3(:)*exp1+B3(:)*exp2)
      QP(1,:)=-AII*G(U)*(A1(:)*Q1*P1+B1(:)*Q2*P2+kx*UP(3,:))
          QP(2,:)=-AII*G(U)*(A2(:)*Q1*P1+B2(:)*Q2*P2+ky*UP(3,:))
          QP(3,:)=LMD(U)*(kx*UP(1,:)+ky*UP(2,:))+LMD2G*(A3(:)*Q1*P1+B3(:)*Q2*P2)
          QP(4,:)=AII*G(U)*(A1(:)*P1*exp1+B1(:)*P2*exp2+kx*UP(6,:))
      QP(5,:)=AII*G(U)*(A2(:)*P1*exp1+B2(:)*P2*exp2+ky*UP(6,:))
          QP(6,:)=-LMD(U)*(kx*UP(4,:)+ky*UP(5,:))-LMD2G*(A3(:)*P1*exp1+B3(:)*P2*exp2)
          UP(3,:)=UP(3,:)*AII
          UP(6,:)=UP(6,:)*AII
          
          COSY=REAL(KX)/REAL(KXY); SINY=-REAL(KY)/REAL(KXY)   
          UH1(1,:)=UP(1,:)*COSY-(UP(2,:))*SINY
          UH1(2,:)=UP(3,:)
          UH1(3,:)=(UP(4,:))*COSY-(UP(5,:))*SINY
          UH1(4,:)=UP(6,:)
          CALL PXP(E1(:,:,U),UH1,QH1,4,4,3)
         
          UH2(1,:)=(UP(1,:))*SINY+(UP(2,:))*COSY
          UH2(2,:)=(UP(4,:))*SINY+(UP(5,:))*COSY
          CALL PXP(E2(:,:,U),UH2,QH2,2,2,3)
          
          QP1(1,:)=QP(1,:)*COSY-(QP(2,:))*SINY
          QP1(2,:)=QP(3,:)
          QP1(3,:)=(QP(4,:))*COSY-(QP(5,:))*SINY
          QP1(4,:)=QP(6,:) 
          
          QP2(1,:)=(QP(1,:))*SINY+(QP(2,:))*COSY
          QP2(2,:)=(QP(4,:))*SINY+(QP(5,:))*COSY
          
          UW=(0.0,0.0);TXYZ=(0.0,0.0)
          
      XQP(1,1)=(-QP1(1,1)-QH1(1,1))/(1.0D0,1.0D0);XQP(2,1)=(-QP1(2,1)-QH1(2,1))/(1.0D0,1.0D0)
      XQP(1,2)=(-QP1(1,2)-QH1(1,2))/(1.0D0,1.0D0);XQP(2,2)=(-QP1(2,2)-QH1(2,2))/(1.0D0,1.0D0)
      XQP(1,3)=(-QP1(1,3)-QH1(1,3))/(1.0D0,1.0D0);XQP(2,3)=(-QP1(2,3)-QH1(2,3))/(1.0D0,1.0D0)
      
      UW(:,1,:)=UWUNIT(:,1,:)*XQP(1,1)+UWUNIT(:,4,:)*XQP(2,1)
      UW(:,2,:)=UWUNIT(:,1,:)*XQP(1,2)+UWUNIT(:,4,:)*XQP(2,2)
      UW(:,3,:)=UWUNIT(:,3,:)*XQP(1,3)+UWUNIT(:,2,:)*XQP(2,3)
      
      TXYZ(:,1,:)=TXYZUNIT(:,1,:)*XQP(1,1)+TXYZUNIT(:,4,:)*XQP(2,1)
      TXYZ(:,2,:)=TXYZUNIT(:,1,:)*XQP(1,2)+TXYZUNIT(:,4,:)*XQP(2,2)
      TXYZ(:,3,:)=TXYZUNIT(:,3,:)*XQP(1,3)+TXYZUNIT(:,2,:)*XQP(2,3)
      
      UWQJ=(0.0,0.0);TXYZQJ=(0.0,0.0)
      UH1(2,:)=-AII*UH1(2,:);UH1(4,:)=-AII*UH1(4,:)
          call pxp(E1_ni(:,:,U),UH1,ABPSV,4,4,3)
          CALL PXP(E13(:,:,U),ABPSV,UWQJ,2,4,3) 
          CALL PXP(E14(:,:,U),ABPSV,TXYZQJ,4,4,3)  
          UW(:,:,U)=UW(:,:,U)+UWQJ 
          TXYZ(:,:,U)=TXYZ(:,:,U)+TXYZQJ 
          
          XQP2(1)=(-QP2(1,1)-QH2(1,1))/(1.0D0,1.0D0)
          XQP2(2)=(-QP2(1,2)-QH2(1,2))/(1.0D0,1.0D0)
          XQP2(3)=(-QP2(1,3)-QH2(1,3))/(1.0D0,1.0D0)
          
          VV(1,:)=VVUNIT(1,:)*XQP2(1);  VV(2,:)=VVUNIT(1,:)*XQP2(2);  VV(3,:)=VVUNIT(2,:)*XQP2(3)
          TYX(1,:)=TYXUNIT(1,:)*XQP2(1);TYX(2,:)=TYXUNIT(1,:)*XQP2(2);TYX(3,:)=TYXUNIT(2,:)*XQP2(3)
          TYZ(1,:)=TYZUNIT(1,:)*XQP2(1);TYZ(2,:)=TYZUNIT(1,:)*XQP2(2);TYZ(3,:)=TYZUNIT(2,:)*XQP2(3)
          
          mx=cs(U)*kXY/w;  t=sqrt(1/mx**2-1);  kt=kXY*t   
      VV(:,U) =VV(:,U)+(UH2(2,:)*sin(kt*d(U)/2)+UH2(1,:)*sin(kt*d(U)/2))/sin(kt*d(U))
      TYZ(:,U)=TYZ(:,U)+kt*G(U)*(UH2(2,:)*cos(kt*d(U)/2)-UH2(1,:)*cos(kt*d(U)/2))/sin(kt*d(U))
      TYX(:,U)=TYX(:,U)-AII*kXY*G(U)*((UH2(2,:)*sin(kt*d(U)/2)+UH2(1,:)*sin(kt*d(U)/2))/sin(kt*d(U))) 
      
          L33=(0.0,0.0);DIS=(0.0,0.0);STR=(0.0,0.0);DISHE1=(0.0,0.0);STRHE1=(0.0,0.0)                          
          L33(1,1)=COSY;L33(1,2)=SINY;L33(2,1)=-SINY;L33(2,2)=COSY;L33(3,3)=1.0D0
          DIS(1,1:3,1:N1)=UW(1,1:3,1:N1)*L33(1,1)+VV(1:3,1:N1)*L33(1,2)
          DIS(2,1:3,1:N1)=UW(1,1:3,1:N1)*L33(2,1)+VV(1:3,1:N1)*L33(2,2)
          DIS(3,1:3,1:N1)=UW(2,1:3,1:N1)
          str(1,1:3,1:N1)=L33(1,1)*L33(1,1)*TXYZ(1,1:3,1:N1)+L33(1,2)*L33(1,2)*TXYZ(2,1:3,1:N1)+2.0*L33(1,1)*L33(1, &
  & 2)*TYX(1:3,1:N1)
          str(2,1:3,1:N1)=L33(2,1)*L33(2,1)*TXYZ(1,1:3,1:N1)+L33(2,2)*L33(2,2)*TXYZ(2,1:3,1:N1)+2.0*L33(2,1)*L33(2, &
  & 2)*TYX(1:3,1:N1)
          str(3,1:3,1:N1)=TXYZ(3,1:3,1:N1)
          str(4,1:3,1:N1)=L33(1,1)*L33(2,1)*TXYZ(1,1:3,1:N1)+L33(1,1)*L33(2,2)*TYX(1:3,1:N1)+L33(1,2)*L33(2,1)*TYX(1:3, &
  & 1:N1)+L33(1,2)*L33(2,2)*TXYZ(2,1:3,1:N1)
          str(5,1:3,1:N1)=L33(1,1)*L33(3,3)*TXYZ(4,1:3,1:N1)+L33(1,2)*L33(3,3)*TYZ(1:3,1:N1)
          str(6,1:3,1:N1)=L33(2,1)*L33(3,3)*TXYZ(4,1:3,1:N1)+L33(2,2)*L33(3,3)*TYZ(1:3,1:N1)
          
      exp1=EXP(AII*P1*z(U))*Q1
          exp2=EXP(AII*P2*z(U))*Q2
      WYTJ(1,:)=(A1(:)*exp1+B1(:)*exp2)
      WYTJ(2,:)=(A2(:)*exp1+B2(:)*exp2)
      WYTJ(3,:)=(A3(:)*exp1+B3(:)*exp2)
          A3B3(:)=A3(:)*P1*exp1+B3(:)*P2*exp2
      YLTJ(1,:)=-AII*kx*LMD2G*WYTJ(1,:)-AII*ky*LMD(U)*WYTJ(2,:)+AII*LMD(U)*A3B3(:)
          YLTJ(2,:)=-AII*LMD(U)*kx*WYTJ(1,:)-AII*LMD2G*ky*WYTJ(2,:)+AII*LMD(U)*A3B3(:)
          YLTJ(3,:)=-AII*LMD(U)*kx*WYTJ(1,:)-AII*LMD(U)*ky*WYTJ(2,:)+AII*LMD2G*A3B3(:)
          YLTJ(4,:)=-AII*G(U)*kx*WYTJ(2,:)-AII*G(U)*ky*WYTJ(1,:) 
          YLTJ(5,:)=AII*G(U)*(A1(:)*P1*exp1+B1(:)*P2*exp2)-AII*G(U)*kx*WYTJ(3,:)
          YLTJ(6,:)=AII*G(U)*(A2(:)*P1*exp1+B2(:)*P2*exp2)-AII*G(U)*ky*WYTJ(3,:)
          
          str(:,:,U)=str(:,:,U)+YLTJ   !TXX,TYY,TZZ,TXY,TZX,TZY
      dis(:,:,U)=dis(:,:,U)+WYTJ
      
          do j=1,M
           DO I=1,N1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
          
          DISHE1(1,1:3)=UW(1,1:3,1+N1)*L33(1,1)+VV(1:3,1+N1)*L33(1,2)
          DISHE1(2,1:3)=UW(1,1:3,1+N1)*L33(2,1)+VV(1:3,1+N1)*L33(2,2)
          DISHE1(3,1:3)=UW(2,1:3,1+N1)
          strHE1(1,1:3)=L33(1,1)*L33(1,1)*tXYZ(1,1:3,1+N1)+L33(1,2)*L33(1,2)*tXYZ(2,1:3,1+N1)+2.0*L33(1,1)*L33(1,2) &
  & *TYX(1:3,1+N1)
          strHE1(2,1:3)=L33(2,1)*L33(2,1)*tXYZ(1,1:3,1+N1)+L33(2,2)*L33(2,2)*tXYZ(2,1:3,1+N1)+2.0*L33(2,1)*L33(2,2) &
  & *TYX(1:3,1+N1)
          strHE1(3,1:3)=tXYZ(3,1:3,1+N1)
          strHE1(4,1:3)=L33(1,1)*L33(2,1)*tXYZ(1,1:3,1+N1)+L33(1,1)*L33(2,2)*TYX(1:3,1+N1)+L33(1,2)*L33(2,1)*TYX(1:3,1+N1) &
  & +L33(1,2)*L33(2,2)*tXYZ(2,1:3,1+N1)
          strHE1(5,1:3)=L33(1,1)*L33(3,3)*tXYZ(4,1:3,1+N1)+L33(1,2)*L33(3,3)*TYZ(1:3,1+N1)
          strHE1(6,1:3)=L33(2,1)*L33(3,3)*tXYZ(4,1:3,1+N1)+L33(2,2)*L33(3,3)*TYZ(1:3,1+N1)
          
      do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as
           END DO      
          enddo
          
          KX=-KX
          dis(2:3,1,:)=-dis(2:3,1,:);dis(1,2:3,:)=-dis(1,2:3,:)
          STR(1:3,1,:)=-STR(1:3,1,:);STR(6,1,:)=-STR(6,1,:)
          STR(4:5,2:3,:)=-STR(4:5,2:3,:)
          do j=1,M
           DO I=1,N1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
          
          disHE1(2:3,1)=-disHE1(2:3,1);disHE1(1,2:3)=-disHE1(1,2:3)
          STRHE1(1:3,1)=-STRHE1(1:3,1);STRHE1(6,1)=-STRHE1(6,1)
          STRHE1(4:5,2:3)=-STRHE1(4:5,2:3)
          do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as
           END DO      
          enddo
          
          KY=-KY
          dis(2,1,:)=-dis(2,1,:);dis(2,3,:)=-dis(2,3,:)
          dis(1,2,:)=-dis(1,2,:);dis(3,2,:)=-dis(3,2,:)
          STR(4,1,:)=-STR(4,1,:);STR(6,1,:)=-STR(6,1,:);STR(4,3,:)=-STR(4,3,:);STR(6,3,:)=-STR(6,3,:)
          STR(1:3,2,:)=-STR(1:3,2,:);STR(5,2,:)=-STR(5,2,:)
          do j=1,M
           DO I=1,N1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
          
          disHE1(2,1)=-disHE1(2,1);disHE1(2,3)=-disHE1(2,3)
          disHE1(1,2)=-disHE1(1,2);disHE1(3,2)=-disHE1(3,2)
          STRHE1(4,1)=-STRHE1(4,1);STRHE1(6,1)=-STRHE1(6,1);STRHE1(4,3)=-STRHE1(4,3);STRHE1(6,3)=-STRHE1(6,3)
          STRHE1(1:3,2)=-STRHE1(1:3,2);STRHE1(5,2)=-STRHE1(5,2)
          do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as
           END DO      
          enddo
          
          KX=-KX
          dis(2:3,1,:)=-dis(2:3,1,:);dis(1,2:3,:)=-dis(1,2:3,:)
          STR(1:3,1,:)=-STR(1:3,1,:);STR(6,1,:)=-STR(6,1,:)
          STR(4:5,2:3,:)=-STR(4:5,2:3,:)
          do j=1,M
           DO I=1,N1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
          
          disHE1(2:3,1)=-disHE1(2:3,1);disHE1(1,2:3)=-disHE1(1,2:3)
          STRHE1(1:3,1)=-STRHE1(1:3,1);STRHE1(6,1)=-STRHE1(6,1)
          STRHE1(4:5,2:3)=-STRHE1(4:5,2:3)
          do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as
           END DO      
          enddo
          
end subroutine

subroutine GreenbUNITTON(kx,ky,KXY,U,length,xmf,ymf,T1,T2,T3,W1,W2,W3,UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
        use quanju
    implicit none
        integer(long) U,i,j,L
        real(double) length,w_2,kx2,ky2,xmf(N1+NN1,M),ymf(N1+NN1,M),YITA,L33(3,3),COSY,SINY
        complex(double) kx,ky,KXY,Q1,Q2,P1,P2,E11,E22,A1(3),A2(3),A3(3),B1(3),B2(3),B3(3),AB(6,3),UP(6,3),QP(6,3),QH(6,3), &
  & dis(3,3,N1),str(6,3,N1)
        complex(double) WYTJ(3,3),WYQJ(3,3),YLTJ(6,3),YLQJ(6,3),uvw(3*(N+1)+10,3),node(3,3),exp1,exp2,as,disHE1(3,3), &
  & strHE1(6,3),v1(2*(N+1)+10,3),v2(N+1+10,3)   
        complex(double) LMDG,LMD2G,P12,P22,A3B3(3),T1(6,N1+NN1,M),T2(6,N1+NN1,M),T3(6,N1+NN1,M),W1(3,N1+NN1,M),W2(3, &
  & N1+NN1,M),W3(3,N1+NN1,M)    
    complex(double) node1(2*(N+1),3),node2(N+1,3),uu(3,N1+1),VV(3,N1+1),ww(3,N1+1),txz(3,N1+1),tYz(3,N1+1),tYX(3, &
  & N1+1),txx(3,N1+1),tzz(3,N1+1),ABPSv(4,3),tYY(3,N1+1),Y(4,3),es,et,u1(3),u2(3),wW1(3),wW2(3),lx,mx,s1,ks,kt,T
    complex(double) UW(2,3,N1+1),TXYZ(4,3,N1+1)
    complex(double) XQP(3),XQP2(2),UWBUNIT(2,2,N1+1),TXYZBUNIT(4,2,N1+1),TYXBUNIT(N1+1),TYZBUNIT(N1+1),VVBUNIT(N1+1) 
      
            
          node1=(0d0,0d0);node2=(0d0,0d0);node=(0d0,0d0);uu=(0,0);VV=(0,0);ww=(0,0);txz=(0,0);tYz=(0,0);tYX=(0,0);txx=(0, &
  & 0);tzz=(0,0);ABPSv=(0,0);tYY=(0,0);Y=(0,0);u1=(0,0);u2=(0,0);wW1=(0,0);wW2=(0,0)
          NODE(1,1)=1.0D0/4.0D0/PI/PI/AII/KY*(EXP(AII*KY*BN(U))/(AII*KX+AII*AN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*AN(U) &
  & *KY*X2(U)))-EXP(AII*KY*DN(U))/(AII*KX+AII*CN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*CN(U)*KY*X2(U))))
          NODE(2,2)=1.0D0/4.0D0/PI/PI/AII/KY*(EXP(AII*KY*BN(U))/(AII*KX+AII*AN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*AN(U) &
  & *KY*X2(U)))-EXP(AII*KY*DN(U))/(AII*KX+AII*CN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*CN(U)*KY*X2(U))))
          NODE(3,3)=1.0D0/4.0D0/PI/PI/KY*(EXP(AII*KY*BN(U))/(AII*KX+AII*AN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*AN(U) &
  & *KY*X2(U)))-EXP(AII*KY*DN(U))/(AII*KX+AII*CN(U)*KY)*(1.0D0-EXP(AII*KX*X2(U)+AII*CN(U)*KY*X2(U))))

          COSY=REAL(KX)/REAL(KXY); SINY=-REAL(KY)/REAL(KXY)   
          XQP(1) =NODE(1,1)*COSY/(1.0D0,1.0D0);XQP(2) =-NODE(2,2)*SINY/(1.0D0,1.0D0);XQP(3)=NODE(3,3)/(1.0D0,1.0D0)
          XQP2(1)=NODE(1,1)*SINY/(1.0D0,1.0D0);XQP2(2)=NODE(2,2)*COSY/(1.0D0,1.0D0)
          
      UW=(0.0,0.0);TXYZ=(0.0,0.0);VV=(0.0,0.0);TYX=(0.0,0.0);TYZ=(0.0,0.0)
          UW(:,1,:)=  UWBUNIT(:,1,:)*XQP(1);   UW(:,2,:)=UWBUNIT(:,1,:)*XQP(2);     UW(:,3,:)=UWBUNIT(:,2,:)*XQP(3)
      TXYZ(:,1,:)=TXYZBUNIT(:,1,:)*XQP(1); TXYZ(:,2,:)=TXYZBUNIT(:,1,:)*XQP(2); TXYZ(:,3,:)=TXYZBUNIT(:,2,:)*XQP(3)
      
      VV(1,:)=VVBUNIT*XQP2(1);    VV(2,:)=VVBUNIT*XQP2(2)
      TYX(1,:)=TYXBUNIT*XQP2(1);  TYX(2,:)=TYXBUNIT*XQP2(2)
          TYZ(1,:)=TYZBUNIT*XQP2(1);  TYZ(2,:)=TYZBUNIT*XQP2(2)
          
          L33=(0.0,0.0);DIS=(0.0,0.0);STR=(0.0,0.0);DISHE1=(0.0,0.0);STRHE1=(0.0,0.0)                        
          L33(1,1)=COSY;L33(1,2)=SINY;L33(2,1)=-SINY;L33(2,2)=COSY;L33(3,3)=1.0D0
          DIS(1,1:3,1:N1)=UW(1,1:3,1:N1)*L33(1,1)+VV(1:3,1:N1)*L33(1,2)
          DIS(2,1:3,1:N1)=UW(1,1:3,1:N1)*L33(2,1)+VV(1:3,1:N1)*L33(2,2)
          DIS(3,1:3,1:N1)=UW(2,1:3,1:N1)
          
          str(1,1:3,1:N1)=L33(1,1)*L33(1,1)*TXYZ(1,1:3,1:N1)+L33(1,2)*L33(1,2)*TXYZ(2,1:3,1:N1)+2.0*L33(1,1)*L33(1, &
  & 2)*TYX(1:3,1:N1)
          str(2,1:3,1:N1)=L33(2,1)*L33(2,1)*TXYZ(1,1:3,1:N1)+L33(2,2)*L33(2,2)*TXYZ(2,1:3,1:N1)+2.0*L33(2,1)*L33(2, &
  & 2)*TYX(1:3,1:N1)
          str(3,1:3,1:N1)=TXYZ(3,1:3,1:N1)
          str(4,1:3,1:N1)=L33(1,1)*L33(2,1)*TXYZ(1,1:3,1:N1)+L33(1,1)*L33(2,2)*TYX(1:3,1:N1)+L33(1,2)*L33(2,1)*TYX(1:3, &
  & 1:N1)+L33(1,2)*L33(2,2)*TXYZ(2,1:3,1:N1)
          str(5,1:3,1:N1)=L33(1,1)*L33(3,3)*TXYZ(4,1:3,1:N1)+L33(1,2)*L33(3,3)*TYZ(1:3,1:N1)
          str(6,1:3,1:N1)=L33(2,1)*L33(3,3)*TXYZ(4,1:3,1:N1)+L33(2,2)*L33(3,3)*TYZ(1:3,1:N1)
          
          do j=1,M
           DO I=1,N1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
      
          DISHE1(1,1:3)=UW(1,1:3,1+N1)*L33(1,1)+VV(1:3,1+N1)*L33(1,2)
          DISHE1(2,1:3)=UW(1,1:3,1+N1)*L33(2,1)+VV(1:3,1+N1)*L33(2,2)
          DISHE1(3,1:3)=UW(2,1:3,1+N1)
          strHE1(1,1:3)=L33(1,1)*L33(1,1)*tXYZ(1,1:3,1+N1)+L33(1,2)*L33(1,2)*tXYZ(2,1:3,1+N1)+2.0*L33(1,1)*L33(1,2) &
  & *TYX(1:3,1+N1)
          strHE1(2,1:3)=L33(2,1)*L33(2,1)*tXYZ(1,1:3,1+N1)+L33(2,2)*L33(2,2)*tXYZ(2,1:3,1+N1)+2.0*L33(2,1)*L33(2,2) &
  & *TYX(1:3,1+N1)
          strHE1(3,1:3)=tXYZ(3,1:3,1+N1)
          strHE1(4,1:3)=L33(1,1)*L33(2,1)*tXYZ(1,1:3,1+N1)+L33(1,1)*L33(2,2)*TYX(1:3,1+N1)+L33(1,2)*L33(2,1)*TYX(1:3,1+N1) &
  & +L33(1,2)*L33(2,2)*tXYZ(2,1:3,1+N1)
          strHE1(5,1:3)=L33(1,1)*L33(3,3)*tXYZ(4,1:3,1+N1)+L33(1,2)*L33(3,3)*TYZ(1:3,1+N1)
          strHE1(6,1:3)=L33(2,1)*L33(3,3)*tXYZ(4,1:3,1+N1)+L33(2,2)*L33(3,3)*TYZ(1:3,1+N1)
          
      do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as 
           END DO      
          enddo
          
          KY=-KY
          dis(2,1,:)=-dis(2,1,:);dis(2,3,:)=-dis(2,3,:)
          dis(1,2,:)=-dis(1,2,:);dis(3,2,:)=-dis(3,2,:)
          STR(4,1,:)=-STR(4,1,:);STR(6,1,:)=-STR(6,1,:);STR(4,3,:)=-STR(4,3,:);STR(6,3,:)=-STR(6,3,:)
          STR(1:3,2,:)=-STR(1:3,2,:);STR(5,2,:)=-STR(5,2,:)
          do j=1,M
           DO I=1,N1
       as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+str(:,1,I)*as
        T2(:,I,j)=T2(:,I,j)+str(:,2,I)*as
                T3(:,I,j)=T3(:,I,j)+str(:,3,I)*as
        W1(:,I,j)=W1(:,I,j)+dis(:,1,I)*as
        W2(:,I,j)=W2(:,I,j)+dis(:,2,I)*as
                W3(:,I,j)=W3(:,I,j)+dis(:,3,I)*as
           END DO      
          enddo
          disHE1(2,1)=-disHE1(2,1);disHE1(2,3)=-disHE1(2,3)
          disHE1(1,2)=-disHE1(1,2);disHE1(3,2)=-disHE1(3,2)
          STRHE1(4,1)=-STRHE1(4,1);STRHE1(6,1)=-STRHE1(6,1);STRHE1(4,3)=-STRHE1(4,3);STRHE1(6,3)=-STRHE1(6,3)
          STRHE1(1:3,2)=-STRHE1(1:3,2);STRHE1(5,2)=-STRHE1(5,2)
          do j=1,M
           DO I=N1+1,N1+NN1
        as=exp(-(0d0,1d0)*(kx*xmf(I,j)+ky*ymf(I,j)))*length
                T1(:,I,j)=T1(:,I,j)+strHE1(:,1)*as
        T2(:,I,j)=T2(:,I,j)+strHE1(:,2)*as
                T3(:,I,j)=T3(:,I,j)+strHE1(:,3)*as
        W1(:,I,j)=W1(:,I,j)+disHE1(:,1)*as
        W2(:,I,j)=W2(:,I,j)+disHE1(:,2)*as
                W3(:,I,j)=W3(:,I,j)+disHE1(:,3)*as
           END DO      
          enddo
          
end subroutine
