function h=fun3d(Ca)
global W;
global CS;
global CP;
global G;
global D;
global THETA;

if isempty(THETA)
    THETA = 0;
end

if ~isfinite(real(Ca)) || ~isfinite(imag(Ca)) || abs(Ca) < eps
    h = NaN + 1i*NaN;
    return;
end
NT=9;                  %��ռ��ϵ�������
D=[2.0,2.0,4.0,3.0,3.0,9.0,12.0,11.0,19.0];                 %������
ZN=[0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.05,0.02];        %���㼰��ռ������
CSL=[181,212,236,187,198,242,285,356,423,521];       %���㼰��ռ���в���
PL=[1900,1780,1900,2050,1930,1890,2120,1890,2050,1930];        %���㼰��ռ��ܶ�
PO=[0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25];          %���㼰��ռ䲴�ɱ�
CPL = CSL.*sqrt(2*(1-PO)./(1-2*PO));

CS = zeros(1,NT+1);
CP = zeros(1,NT+1);
G  = zeros(1,NT+1);
LMD = zeros(1,NT+1);
for ii = 1:NT+1
    A2 = 1 + 2i*ZN(ii);
    CS(ii) = CSL(ii)^2*A2;
    CP(ii) = CPL(ii)^2*A2;
    G(ii) = CS(ii)*PL(ii);
    LMD(ii) = 2*PO(ii)/(1-2*PO(ii))*G(ii);
end

KX = W/Ca*cos(THETA*pi/180.0);
KY = W/Ca*sin(THETA*pi/180.0);

E = zeros(6,6,NT);
for ii = 1:NT
    E(:,:,ii) = layerkk(ii,KX,KY);
end

CS1 = sqrt(CS(NT+1));
CP1 = sqrt(CP(NT+1));
MU = G(NT+1);
LMD2G = LMD(NT+1) + 2.0*MU;

LX = CP1*KX/W;  LY = CP1*KY/W;  LZ = sqrt(1.0 - LX^2 - LY^2);
LZ = abs(real(LZ)) - 1i*abs(imag(LZ));
KPZ = W*LZ/CP1;

MX = CS1*KX/W;  MY = CS1*KY/W;  MZ = sqrt(1.0 - MX^2 - MY^2);
MZ = abs(real(MZ)) - 1i*abs(imag(MZ));
KSZ = W*MZ/CS1;

S5 = LX*MX + LY*MY + LZ*MZ;
Ehf = zeros(3,3);
Ehf(1,1) = 1i*(LX*KPZ*MX + LZ*MZ*KSZ + MY*KSZ*LY)*MU/S5;
Ehf(1,2) = 1i*(KPZ - KSZ)*LX*MU*MY/S5;
Ehf(1,3) = (KX*S5 + MZ*LX*(KPZ - KSZ))*MU/S5;
Ehf(2,2) = 1i*(KSZ*LX*MX + MY*LY*KPZ + LZ*MZ*KSZ)*MU/S5;
Ehf(2,3) = (KY*S5 + MZ*LY*(KPZ - KSZ))*MU/S5;
Ehf(3,3) = 1i*(KSZ*(LX*MX + MY*LY) + MZ*LZ*KPZ)*LMD2G/S5;
Ehf(2,1) = Ehf(1,2);
Ehf(3,1) = Ehf(1,3);
Ehf(3,2) = Ehf(2,3);


ndof = 3*(NT+1);
SS = zeros(ndof,ndof);
for ii = 1:NT
    top = 3*(ii-1)+1 : 3*ii;
    bot = 3*ii+1 : 3*(ii+1);

    for r = 1:3
        for c = r:3
            SS(top(r),top(c)) = SS(top(r),top(c)) + E(r,c,ii);
            SS(top(c),top(r)) = SS(top(r),top(c));
        end
    end

    for r = 1:3
        for c = 1:3
            SS(top(r),bot(c)) = SS(top(r),bot(c)) + E(r,c+3,ii);
            SS(bot(c),top(r)) = SS(top(r),bot(c));
        end
    end

    for r = 1:3
        for c = r:3
            SS(bot(r),bot(c)) = SS(bot(r),bot(c)) + E(r+3,c+3,ii);
            SS(bot(c),bot(r)) = SS(bot(r),bot(c));
        end
    end
end

last = ndof-2:ndof;
for r = 1:3
    for c = r:3
        SS(last(r),last(c)) = SS(last(r),last(c)) + Ehf(r,c);
        SS(last(c),last(r)) = SS(last(r),last(c));
    end
end

scale = max(abs(SS(:)));
if ~isfinite(scale) || scale == 0
    h = NaN + 1i*NaN;
else
    h = det(SS/scale);
end
