﻿clear all
global W;
% W=0.05;
c0=521;
c1=520;
q=1e-8;
n=0;
% lll=802;

rrr=0.0;ttt=0.0;

% for AT=0.005:0.005:0.275;
%     n=n+1;
%     rc(n)=0.0;
%     ic(n)=0.0;
% end

 fim=fopen('a.txt','w');
% fin=fopen('pinsanratio22.txt','w');
for idx=1:300
freq=0.10+(idx-1)*0.04;
AT=4*pi*freq/181;
W=181.0*AT/2.0;
 n=n+1;   
 wlg(n)=freq;
 www=AT;
 c=fun443(c0);
 sdsad(n)=c
 if c==0
    fprintf(fim,'%12.8f %12.8f\r\n',W,AT); 
 end
end
% c=newton('fun443',c0,c1,q);
% t(n)=abs(c)^2/real(c);
% t1(n)=c;
%    c0=t1(n)-0.1;
%    c1=t1(n)-0.1001;
 
% if AT>0.4
%    c0=t1(n)-819.0-50i;
%    c1=t1(n)-819.0001-72i;
% else
%   c0=t1(n)-0.1;
%   c1=t1(n)-0.101;
% end

% rc(n)=real(c);
% ic(n)=imag(c);
%save('mod2.txt','rc','ic','-ASCII','-append') *********************
% ratio(n)=ic(n)/rc(n);
% end
% realc=rc';
% imc=ic';
% hold on
% plot(wlg,t)

% fid=fopen('pinsan22.txt','w');
% fic=fopen('pinsanratio22.txt','w');
% for mi=1:lll
%     fprintf(fid,'%12.8f %12.8f\r\n',wlg(mi),t(mi)/1000);
%     fprintf(fic,'%12.8f %12.8f\r\n',wlg(mi),ratio(mi));
% end
% fclose(fid);
% fclose(fic);
    

%************************************************************************%
% w1=0.05:1:999.05;
% w2=w1*30/352.84
% 
% 
% W=37.7;
% c0=500;
% c1=495;
% q=1e-8;
% for n=1:1000;
% c=newton('fun443',c0,c1,q);
% s(n)=abs(c)^2/real(c);
% s1(n)=c;
% W=W+1;
% c0=s1(n);
% c1=s1(n)-0.01;
% end;
% v1=37.7:1:1036.7;
% v2=v1*30/352.84;
% 
% 
% 
% W=90.4;
% c0=500;
% c1=495;
% q=1e-8;
% for n=1:1000;
% c=newton('fun443',c0,c1,q);
% l(n)=abs(c)^2/real(c);
% l1(n)=c;
% W=W+1;
% c0=l1(n);
% c1=l1(n)-0.2;
% end;
% u1=90.4:1:1089.4;
% u2=u1*30/352.84;
% 
% w3=0:1:999;
% plot(w2,t,v2,s,u2,l,w3,352.84*ones(1000),'--');
% axis([0,50,300,500]);
% xlabel('������Ƶ��{\omega}d/{c}_{s}^{L}');
% ylabel('���������ٶ�Ca')