#!/usr/bin/env python3
"""Fresh directory per run. Never appends old K/delta rows."""
import argparse,datetime,json,os,pathlib,shutil,subprocess,sys
p=argparse.ArgumentParser(description='Rayleigh 0-degree trial build; unit surface vertical displacement')
p.add_argument('site',choices=['1','2','3']);p.add_argument('points',type=int,choices=range(1,301));p.add_argument('--free-only',action='store_true');p.add_argument('--threads',type=int,default=4)
a=p.parse_args()
if a.threads<1: p.error('--threads must be positive')
base=pathlib.Path(__file__).resolve().parent;site={'1':'场地一','2':'场地二','3':'场地三'}[a.site]
exe=base/site/'build'/('rayleigh.exe' if os.name=='nt' else 'rayleigh')
if not exe.exists():p.error('Build first: build_windows.bat (Intel oneAPI) or build.sh (GNU Fortran)')
stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S.%fZ')
d=base/'runs'/f'{site}_{a.points}pt_{"free" if a.free_only else "full"}_{stamp}';d.mkdir(parents=True)
for sub in ('K','delta'):(d/sub).mkdir()
shutil.copy2(base/site/'CA.txt',d/'CA.txt')
meta={'site':site,'points_requested':a.points,'free_only':a.free_only,'azimuth_deg':0,'normalization':'physical surface vertical displacement = 1+0i','status':'running','threads_limit':a.threads,'full_calculation_validated':False}
(d/'run.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
if os.name!='nt':
 import resource
 soft,hard=resource.getrlimit(resource.RLIMIT_STACK)
 resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
env=os.environ.copy();env.update(OMP_NUM_THREADS=str(a.threads),OMP_THREAD_LIMIT=str(a.threads),OMP_STACKSIZE='512M',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1')
cmd=[str(exe),str(a.points)]+(['--free-only'] if a.free_only else [])
print('Run directory:',d,flush=True)
with (d/'console.log').open('w',encoding='utf-8') as f:
 process=subprocess.Popen(cmd,cwd=d,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,errors='replace',bufsize=1)
 try:
  for line in process.stdout:
   print(line,end='',flush=True);f.write(line);f.flush()
  rc=process.wait()
 except KeyboardInterrupt:
  process.terminate();rc=process.wait();meta['interrupted']=True
meta.update(status='completed' if rc==0 else 'failed',exit_code=rc)
if rc==0 and not a.free_only:
 try:
  names=['K/KHH.txt','K/KVV.txt','K/KMM.txt','K/KTT.txt','K/KHM.txt','K/KMH.txt','delta/deltx.txt','delta/delty.txt','delta/deltz.txt','delta/rx.txt','delta/ry.txt','delta/rz.txt']
  if any(len((d/n).read_text().splitlines())!=a.points for n in names):raise ValueError('output row count mismatch')
  if len((d/'completed_frequencies.csv').read_text().splitlines())!=a.points+1:raise ValueError('frequency completion count mismatch')
  meta['structural_output_checks_passed']=True
 except (OSError,ValueError) as e:meta.update(status='failed',validation_error=str(e));rc=2
(d/'run.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print('Exit:',rc,'; see console.log and run.json. A zero exit is not physical validation.',flush=True)
sys.exit(rc)
