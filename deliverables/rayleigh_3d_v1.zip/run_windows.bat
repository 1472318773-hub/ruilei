@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
if not "%~1"=="" if not "%~1"=="1" if not "%~1"=="2" if not "%~1"=="3" exit /b 2
set "SITE=场地一"
if "%~1"=="2" set "SITE=场地二"
if "%~1"=="3" set "SITE=场地三"
set "POINTS=%~2"
if "%POINTS%"=="" set "POINTS=1"
if not exist "%SITE%\build\rayleigh.exe" (
 echo Build first using build_windows.bat in Intel oneAPI x64 command prompt.
 exit /b 1
)
set "RUN_DIR=%CD%\runs\%SITE%_%POINTS%pt_%RANDOM%_%RANDOM%"
if exist "%RUN_DIR%" exit /b 1
mkdir "%RUN_DIR%\K"
mkdir "%RUN_DIR%\delta"
copy "%SITE%\CA.txt" "%RUN_DIR%\CA.txt" >nul
set "OMP_NUM_THREADS=4"
set "OMP_THREAD_LIMIT=4"
set "OMP_STACKSIZE=512M"
set "MKL_NUM_THREADS=1"
set "OPENBLAS_NUM_THREADS=1"
echo Run directory: %RUN_DIR%
set "EXE=%CD%\%SITE%\build\rayleigh.exe"
pushd "%RUN_DIR%"
"%EXE%" %POINTS% %~3 > console.log 2>&1
set "RC=%ERRORLEVEL%"
type console.log
echo %RC% > exit_code.txt
popd
exit /b %RC%
