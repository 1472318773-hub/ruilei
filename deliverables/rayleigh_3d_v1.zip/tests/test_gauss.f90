program test_gauss
 use e_digit, only: double
 implicit none
 integer,parameter:: ns=20,ms=6
 integer i,j
 complex(double) a(ns,ns),b(ns,ms),truth(ns,ms),x(ns,ms),y(ns,ms)
 real(double) err,rel
 do i=1,ns
   do j=1,ns
     a(i,j)=cmplx(sin(dble(i+j)),cos(dble(i-j)),double)
   enddo
   a(i,i)=a(i,i)+20d0+i
   do j=1,ms
     truth(i,j)=cmplx(cos(dble(i*j)),sin(dble(i+j)),double)
   enddo
 enddo
 b=matmul(a,truth)
 call GAUSS(a,b,x,ns,ms)
 call supGAUSS(a,b,y,ns,ms)
 err=max(maxval(abs(x-truth)),maxval(abs(y-truth)))
 rel=maxval(abs(matmul(a,y)-b))/maxval(abs(b))
 write(*,*) 'GAUSS_AND_SUPGAUSS_KNOWN_SOLUTION_ERROR',err,'RESIDUAL',rel
 if(err>1d-11.or.rel>1d-12) error stop 'Known solution failed'
end program
