@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "FC=ifx"
where ifx >nul 2>nul
if errorlevel 1 set "FC=ifort"
where %FC% >nul 2>nul
if errorlevel 1 (
  echo Open Intel oneAPI x64 command prompt with Visual Studio environment first.
  exit /b 1
)
for %%S in (场地一 场地二 场地三) do (
  if not exist "%%S\build" mkdir "%%S\build"
  pushd "%%S\build"
  %FC% /nologo /O2 /free /extend-source:132 /Qopenmp /Qmkl:sequential /check:bounds /fpe:0 /traceback /exe:rayleigh.exe ..\main.f90 ..\indata.f90 ..\openfile.f90 ..\region.f90 ..\dk.f90 ..\green.f90 ..\integral.f90 ..\gauss.f90 ..\solv.f90 ..\free.f90 /link /STACK:1073741824 > compile.log 2>&1
  if errorlevel 1 (
    type compile.log
    popd
    exit /b 1
  )
  popd
)
echo All three sites compiled. Run with: run_windows.bat 1 1
