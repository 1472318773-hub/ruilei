	
	
  subroutine freefield(IP,faix,faiy,tf,vf)
	use quanju
	implicit none	
	integer(long) IP,i,j,ij,h,L,jh,LWORK,INFO
	real(double) faix,faiy,AP,ASV,ASH,RWORK(6*(N+1))
    complex(double) dis(3,N1),str(6,N1),AB(6),as,lx,ly,lz,mx,my,mz,kx,ky,kpz,ksz,C1(3,3),C2(3,3),C3(3,3),BPSvSh(3),u0,v0,w0
	complex(double) node(3*(N+1)),uvw(3*(N+1)+10),disHE1(3),strHE1(6)	
    complex(double) tf(:),vf(:),SSF(3*(N+1),3*(N+1)),LAMD(3*(N+1),VL(3*(N+1),3*(N+1)),VR(3*(N+1),3*(N+1)),WORK(1000)  
     
	 
     kx=w/Ca*cos(faix*PI/180)
     ky=w/Ca*sin(faix*PI/180)
     
     CALL DKFREE(kx,ky)
     SSF=(0D0,0D0);SSF=SS
     WORK=(0D0,0D0);LWORK=1000D0
     call zgeev('v','v',3*(N+1),SSF,3*(N+1),LAMD,VL,3*(N+1),VR,3*(N+1),WORK,LWORK,RWORK,INFO)
     
     
     node=(0d0,0d0)
	 node(3*N+1)=Ehf(1,1)*U0+Ehf(1,2)*V0+Ehf(1,3)*W0*AII
     node(3*N+2)=Ehf(2,1)*U0+Ehf(2,2)*V0+Ehf(2,3)*W0*AII
     node(3*N+3)=Ehf(3,1)*U0+Ehf(3,2)*V0+Ehf(3,3)*W0*AII
     
     CALL Solv(3*(N+1),6,K,node,uvw,1)
	 		
	 do i=1,N1
       call pxp(E1_niF(:,:,i),uvw(3*i-2:3*i+3),AB,6,6,1)
       call pxp(E3(:,:,i),AB,dis(:,i),3,6,1)
       call pxp(E4(:,:,i),AB,str(:,i),6,6,1)
     enddo
     vf=(0d0,0d0); tf=(0d0,0d0)	
     do ij=1,NZ
       call image(ij,i,j,L)
       do h=1,L
         jh=(j-1)*L+h
         as=exp(-AII*kx*xm2(i,jh))*exp(-AII*ky*ym2(i,jh))
         vf(ij)=vf(ij)+dis(1,i)*as/abs(as)/L
         vf(NZ+ij)=vf(NZ+ij)+dis(2,i)*as/abs(as)/L
         vf(2*NZ+ij)=vf(2*NZ+ij)+dis(3,i)*as/abs(as)/L
         tf(ij)=tf(ij)+(str(1,i)*nx2(i,jh)+str(4,i)*ny2(i,jh)+str(5,i)*nz2(i,jh))*as/abs(as)*sa(i)
         tf(NZ+ij)=tf(NZ+ij)+(str(4,i)*nx2(i,jh)+str(2,i)*ny2(i,jh)+str(6,i)*nz2(i,jh))*as/abs(as)*sa(i)
         tf(2*NZ+ij)=tf(2*NZ+ij)+(str(5,i)*nx2(i,jh)+str(6,i)*ny2(i,jh)+str(3,i)*nz2(i,jh))*as/abs(as)*sa(i)
       enddo
	 enddo
	 DO I=1,N1
	   DO J=1,M
	     IJ=(I-1)*M+J
	     as=exp(-AII*kx*xm2(i,j))*exp(-AII*ky*ym2(i,j))
	     VF(IJ)     =dis(1,i)*as/abs(as)
	     VF(NT+IJ)  =DIS(2,I)*as/abs(as)
	     VF(2*NT+IJ)=DIS(3,I)*as/abs(as)
	     TF(IJ)     =(STR(1,I)*NX2(I,J)+STR(4,I)*NY2(I,J)+STR(5,I)*NZ2(I,J))*as/abs(as)*sa(i)
	     TF(NT+IJ)  =(STR(4,I)*NX2(I,J)+STR(2,I)*NY2(I,J)+STR(6,I)*NZ2(I,J))*as/abs(as)*sa(i)
	     TF(2*NT+IJ)=(STR(5,I)*NX2(I,J)+STR(6,I)*NY2(I,J)+STR(3,I)*NZ2(I,J))*as/abs(as)*sa(i)
	   END DO
	 END DO	 
	 AB=(0.0,0.0) 
	 call pxp(E1_niF(:,:,N1+1),uvw(3*(N1+1)-2:3*(N1+1)+3),AB,6,6,1)
     call pxp(E3HE1F(:,:),AB,disHE1(:),3,6,1)
     call pxp(E4HE1F(:,:),AB,strHE1(:),6,6,1)
     
     DO I=N1+1,N1+NN1
	   DO J=1,M
	     IJ=(I-1)*M+J
	     as=exp(-AII*kx*xm2(i,j))*exp(-AII*ky*ym2(i,j))
	     VF(IJ)     =disHE1(1)*as/abs(as)
	     VF(NT+IJ)  =disHE1(2)*as/abs(as)
	     VF(2*NT+IJ)=disHE1(3)*as/abs(as)
	     TF(IJ)     =(strHE1(1)*NX2(I,J)+strHE1(4)*NY2(I,J)+strHE1(5)*NZ2(I,J))*as/abs(as)*sa(i)
	     TF(NT+IJ)  =(strHE1(4)*NX2(I,J)+strHE1(2)*NY2(I,J)+strHE1(6)*NZ2(I,J))*as/abs(as)*sa(i)
	     TF(2*NT+IJ)=(strHE1(5)*NX2(I,J)+strHE1(6)*NY2(I,J)+strHE1(3)*NZ2(I,J))*as/abs(as)*sa(i)
	   END DO
	 END DO	 
	  
  end subroutine
