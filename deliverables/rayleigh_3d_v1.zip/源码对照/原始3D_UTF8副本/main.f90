 
module e_digit
  integer,parameter:: double=selected_real_kind(13,200)
  integer,parameter:: long=selected_int_kind(7)
  integer(long) Z1,Z2,Z4,Z8,Z16,NZ
  integer(long),parameter:: N1=32,N2=20
  integer(long),parameter:: NN1=8,M=64,N=N1+N2,NT=(N1+NN1)*M,N0=5
  integer(long),parameter:: M2=M/2,M4=M/4,M8=M/8,M16=M/16
  integer(long),parameter:: F2=N1+NN1+1,F4=N1+NN1+1,F8=N1+NN1+1,F16=N1+NN1+1    
  integer(long),parameter:: IC=12
  real(double),parameter:: PI=3.1415926535897932d0
  complex(double),parameter:: AII=(0d0,1d0) 
end module     

module quanju
  use e_digit   
  real(double),save:: x1(N1+NN1),x2(N1+NN1),x3(N1+NN1),y1(N1+NN1),y2(N1+NN1),y3(N1+NN1),sa(N1+NN1),z(N1+NN1),w,cs_L,cs_R,zna(N+1),znB(N+1),P(N+1),D(N),R,HEIG
  real(double),save:: nx1(N1+NN1,M),ny1(N1+NN1,M),nz1(N1+NN1,M),DS1(N1+NN1),xm1(N1+NN1,M),ym1(N1+NN1,M),xmx1(N1+NN1,M,N1+NN1)
  real(double),save:: nx2(N1+NN1,M),ny2(N1+NN1,M),nz2(N1+NN1,M),DS2(N1+NN1),xm2(N1+NN1,M),ym2(N1+NN1,M),xmx2(N1+NN1,M,N1+NN1)
  real(double),save:: xm(N1+NN1,M),ym(N1+NN1,M),zm(N1+NN1)
  real(double),save:: an(N1+NN1),bn(N1+NN1),cn(N1+NN1),dn(N1+NN1),en(N1+NN1)
  complex(double),save:: CS(N+1),CP(N+1),G(N+1),LMD(N+1)
  complex(double),save:: E1ni(4,4,N1+1),E1_ni(4,4,N1+1),II(6,6),K1(2*(N+1),4),K2(N+1,3),Ehf(3,3),E3HE1(3,6),E4HE1(6,6),E1(4,4,N+1),E2(2,2,N+1),E13(2,4,N1+1),E14(4,4,N1+1)
  complex(double),save:: K(3*(N+1),6),E(6,6,N),E1_niF(6,6,N),E3(3,6,N1),E4(6,6,N1),E3HE1F(3,6),E4HE1F(6,6),SS(3*(N+1),3*(N+1))
  integer(long),parameter:: XC=16
  !$OMP threadprivate(E1_ni,E1ni,K1,K2,E3HE1,E4HE1,E1,E2,E13,E14)
end module



program MAIN
  use quanju
  implicit none
  interface 
    
    subroutine integral(Gv1,Gs1)
	  use quanju
      implicit none
     integer(long),parameter:: NJ=1500,ND=200
    integer(long) U,i,j,i1,j1,j11,id,ij,G1,G2,G3,G4,ierr,iL,iR
    real(double) length,thta,time
    complex(double) kx,ky,KXY,Gs1(:,:),Gv1(:,:)
	complex(double) T1(6,N1+NN1,M,N1+NN1),T2(6,N1+NN1,M,N1+NN1),T3(6,N1+NN1,M,N1+NN1),W1(3,N1+NN1,M,N1+NN1),W2(3,N1+NN1,M,N1+NN1),W3(3,N1+NN1,M,N1+NN1)
    complex(double) RT1(6,N1+NN1,M,N1+NN1),RT2(6,N1+NN1,M,N1+NN1),RT3(6,N1+NN1,M,N1+NN1),RW1(3,N1+NN1,M,N1+NN1),RW2(3,N1+NN1,M,N1+NN1),RW3(3,N1+NN1,M,N1+NN1)
    complex(double) UWUNIT(2,4,N1+1,N1),TXYZUNIT(4,4,N1+1,N1),VVUNIT(2,N1+1,N1),tYzUNIT(2,N1+1,N1),tYXUNIT(2,N1+1,N1)
    complex(double) UWBUNIT(2,4,N1+1),TXYZBUNIT(4,4,N1+1),VVBUNIT(N1+1),tYzBUNIT(N1+1),tYXBUNIT(N1+1)
    real(double)  DUANK(NJ),DUANKX(ND,NJ),DUANKY(ND,NJ),DKS(NJ)
    end subroutine
    subroutine freefield(IP,ALFX,ALFY,tf,vf)
	  use quanju
	  implicit none	
	  integer(long) IP,i,j,ij,h,L,jh
	  real(double) ALFX,ALFY,AP,ASV,ASH
      complex(double) dis(3,N1),str(6,N1),AB(6),as,lx,ly,lz,mx,my,mz,kx,ky,kpz,ksz,C1(3,3),C2(3,3),C3(3,3),BPSvSh(3),u0,v0,w0
	  complex(double) node(3*(N+1)),uvw(3*(N+1)+10)	
      complex(double) tf(:),vf(:)
    end subroutine
  end interface
  integer(long) U,IP,i,j,i1,j1,ij,ij1,JC,rank,ierr,kuan,KL,ZL,O,L,L1,C,CR,CM
  real(double) faix,faiy,thta,ETA
  complex(double) Kjc(6,6),delta(6,IC),wyf(N0,5,3,IC),wy(N0,5,3,IC)
  complex(double),allocatable:: cof(:,:),tf(:,:),vf(:,:),vs(:,:),Gs(:,:),Gv(:,:),dw1(:,:),lm(:,:),Fv(:,:),Gv1(:,:),Gs1(:,:)
  
    call openfile
    Z1=(F2-1)*M
    Z2=(F4-F2)*M2
    Z4=(F8-F4)*M4 
    Z8=(F16-F8)*M8
    Z16=(N1+NN1-F16+1)*M16
    NZ=Z1+Z2+Z4+Z8+Z16
    
   
    call indata

    K1=(0d0,0d0);K2=(0d0,0d0);E1_ni=(0d0,0d0);II=(0d0,0d0);E1=(0d0,0d0);E2=(0d0,0d0)
    do i=1,6
      II(i,i)=(1d0,0d0)   !!!! very important
    enddo
    


    do ETA=0.025d0,3.00001d0,0.025d0
      
      write(1010,*) ETA
      write(*,*) ETA
      w=cs_L*ETA/R
      allocate(Gs1(3*NT,3*(N1+NN1)),Gv1(3*NT,3*(N1+NN1)),stat=ierr)
      call integral(Gv1,Gs1) 
	  allocate(Gv(3*NZ,3*NZ),Gs(3*NZ,3*NZ),stat=ierr)
	  
      Gv=(0d0,0d0); Gs=(0d0,0d0)
      do IJ=1,3*NZ
        O=(ij-1)/NZ
        call image(ij,i,j,L)
        do ij1=1,NZ
          call image(ij1,i1,j1,L1)
          call GvGs(L,L1)
        enddo
      enddo      
      
      deallocate(Gs1,Gv1)
      allocate(dw1(3*NZ,6),lm(3*NZ,6),Fv(3*NZ,6),stat=ierr)
      
	  dw1=(0d0,0d0)
      dw1(1:NZ,1)=(1d0,0d0)
      dw1(NZ+1:2*NZ,2)=(1d0,0d0)
      dw1(2*NZ+1:3*NZ,3)=(1d0,0d0)
      do ij=1,NZ
        call image(ij,i,j,L)
        dw1(NZ+ij,4)=(zm(i)); dw1(2*NZ+ij,4)=-ym(i,j)
        dw1(ij,5)=-(zm(i));   dw1(2*NZ+ij,5)=xm(i,j)
	    dw1(ij,6)=ym(i,j);  dw1(NZ+ij,6)=-xm(i,j)
      enddo
      
      CALL supGAUSS(GV,DW1,LM,3*NZ,6)
      CALL PXP(Gs,lm,Fv,3*NZ,3*NZ,6)
      deallocate(Gs)
      
      call tx(dw1,Fv,Kjc,3*NZ,6,6)         !Kjc=(.t.dw1).x.Fv
      
        !write(1010,*) 'write K,Fv,lm'
        write(2001,*) Kjc(1,1)/(cs_L**2*p(1)) 
        write(2002,*) Kjc(3,3)/(cs_L**2*p(1)) 
        write(2003,*) Kjc(4,4)/(cs_L**2*p(1)) 
        write(2004,*) Kjc(6,6)/(cs_L**2*p(1)) 
        write(2005,*) Kjc(1,5)/(cs_L**2*p(1)) 
        write(2006,*) Kjc(5,1)/(cs_L**2*p(1))
      
      allocate(vf(3*NZ,IC),tf(3*NZ,IC),vs(3*NZ,IC),stat=ierr)
      call jc_delta

      deallocate(Gv,dw1,lm,Fv,vf,tf,vs)
  
    enddo

 	


    contains
      subroutine GvGs(L,L1)
        integer(long) L,L1,h,h1,jh,j1h,id
        complex(double) Gvh(3),Gsh(3)
          do h=1,L
            jh=(j-1)*L+h
            thta=(jh-1)*2*PI/M
            do h1=1,L1
              j1h=(j1-1)*L1+h1
              if(j1h<=jh-1)then
                id=(i1-1)*M+j1h-jh+1+M
              else
                id=(i1-1)*M+j1h-jh+1
              endif
              Gvh(1)=Gv1(id,i+O*(N1+NN1))*cos(thta)-Gv1(id+NT,i+O*(N1+NN1))*sin(thta)
              Gvh(2)=Gv1(id,i+O*(N1+NN1))*sin(thta)+Gv1(id+NT,i+O*(N1+NN1))*cos(thta)
              Gvh(3)=Gv1(id+2*NT,i+O*(N1+NN1))
              Gsh(1)=Gs1(id,i+O*(N1+NN1))*cos(thta)-Gs1(id+NT,i+O*(N1+NN1))*sin(thta)
              Gsh(2)=Gs1(id,i+O*(N1+NN1))*sin(thta)+Gs1(id+NT,i+O*(N1+NN1))*cos(thta)
              Gsh(3)=Gs1(id+2*NT,i+O*(N1+NN1))
              Gv(ij1,IJ)=Gv(ij1,IJ)+Gvh(1)/L1
              Gv(NZ+ij1,IJ)=Gv(NZ+ij1,IJ)+Gvh(2)/L1
              Gv(2*NZ+ij1,IJ)=Gv(2*NZ+ij1,IJ)+Gvh(3)/L1
              Gs(ij1,IJ)=Gs(ij1,IJ)+Gsh(1)*sa(i1)
              Gs(NZ+ij1,IJ)=Gs(NZ+ij1,IJ)+Gsh(2)*sa(i1)
              Gs(2*NZ+ij1,IJ)=Gs(2*NZ+ij1,IJ)+Gsh(3)*sa(i1)
            enddo
          enddo 
      end subroutine
      subroutine jc_delta
        complex(double) delta1(6,IC)
          delta1=(0d0,0d0)
          faiy=90d0
          do IP=1,3
            do U=1,4
              if(U==1)then
		        faix=5d0
		      else if(U==2)then
                faix=30d0
		      else if(U==3)then
		        faix=60d0
		      else if(U==4)then
		        faix=89.9d0
		      endif
              ij=(IP-1)*4+U
              call freefield(IP,faix,faiy,tf(:,ij),vf(:,ij))  
              do i=1,6
                do j=1,3*NZ
	              delta1(i,ij)=delta1(i,ij)+Fv(j,i)*vf(j,ij)-dw1(j,i)*tf(j,ij)
	            enddo
              enddo
              call GAUSS(Kjc,delta1(:,ij),delta(:,ij),6,1)    !delta=Kjc.ix.delta1
              
              do i=1,6
                ij1=6*(ij-1)+i
                  !write(1010,*) 'write delta'
                  write(3000+ij1,*) delta(i,ij)
                  !write(1010,*) 'over'
              enddo
            enddo
          enddo
      end subroutine
      
end program main
	



	 


