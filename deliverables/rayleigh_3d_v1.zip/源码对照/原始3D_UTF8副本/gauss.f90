

  
  SUBROUTINE GAUSS(A,B,X,N,M)
    implicit none 
    integer(4) N,M,I,J,L,JS(N),K,IS
    complex(8) A(N,N),B(N,M),X(N,M)  
    real(8) AR(N,N),AI(N,N),BR(N,M),BI(N,M),D,P,Q,S
      AR=dble(A); AI=dimag(A); BR=dble(B); BI=dimag(B)
	  do K=1,N-1
		D=0d0
		do J=K,N
		  do I=K,N
		    P=AR(I,J)*AR(I,J)+AI(I,J)*AI(I,J)
			if(P>D)then
			  D=P; JS(K)=J; IS=I
			endif
          enddo
	    enddo
	    do J=K,N
		  P=AR(K,J); AR(K,J)=AR(IS,J); AR(IS,J)=P
		  P=AI(K,J); AI(K,J)=AI(IS,J); AI(IS,J)=P		   					  	    
        enddo
		do L=1,M
	      P=BR(K,L); BR(K,L)=BR(IS,L); BR(IS,L)=P
		  P=BI(K,L); BI(K,L)=BI(IS,L); BI(IS,L)=P
		enddo
		do I=1,N
		  P=AR(I,K); AR(I,K)=AR(I,JS(K)); AR(I,JS(K))=P
		  P=AI(I,K); AI(I,K)=AI(I,JS(K)); AI(I,JS(K))=P
        enddo
		do J=K+1,N
		  P=AR(K,J)*AR(K,K)
		  Q=-AI(K,J)*AI(K,K)
		  S=(AR(K,K)-AI(K,K))*(AR(K,J)+AI(K,J))
		  AR(K,J)=(P-Q)/D
		  AI(K,J)=(S-P-Q)/D
        enddo
		do L=1,M
	      P=BR(K,L)*AR(K,K)
		  Q=-BI(K,L)*AI(K,K)
		  S=(AR(K,K)-AI(K,K))*(BR(K,L)+BI(K,L))
		  BR(K,L)=(P-Q)/D
		  BI(K,L)=(S-P-Q)/D
		enddo
		do J=K+1,N
		  do I=K+1,N
			P=AR(I,K)*AR(K,J)
			Q=AI(I,K)*AI(K,J)
			S=(AR(I,K)+AI(I,K))*(AR(K,J)+AI(K,J))
			AR(I,J)=AR(I,J)-P+Q
			AI(I,J)=AI(I,J)-S+P+Q
          enddo
        enddo
        do I=K+1,N
		  do L=1,M
            P=AR(I,K)*BR(K,L)
		    Q=AI(I,K)*BI(K,L)
	   	    S=(AR(I,K)+AI(I,K))*(BR(K,L)+BI(K,L))
		    BR(I,L)=BR(I,L)-P+Q
	   	    BI(I,L)=BI(I,L)-S+P+Q
	      enddo
        enddo
      enddo
	  D=AR(N,N)*AR(N,N)+AI(N,N)*AI(N,N)
	  do L=1,M
	    P=AR(N,N)*BR(N,L)
	    Q=-AI(N,N)*BI(N,L)
	    S=(AR(N,N)-AI(N,N))*(BR(N,L)+BI(N,L))
	    BR(N,L)=(P-Q)/D
	    BI(N,L)=(S-P-Q)/D
	    do I=N-1,1,-1
	      do J=I+1,N
		    P=AR(I,J)*BR(J,L)
		    Q=AI(I,J)*BI(J,L)
		    S=(AR(I,J)+AI(I,J))*(BR(J,L)+BI(J,L))
		    BR(I,L)=BR(I,L)-P+Q
		    BI(I,L)=BI(I,L)-S+P+Q
          enddo
        enddo
        JS(N)=N
	    do K=N,1,-1
	      P=BR(K,L); BR(K,L)=BR(JS(K),L); BR(JS(K),L)=P
	   	  P=BI(K,L); BI(K,L)=BI(JS(K),L); BI(JS(K),L)=P
        enddo
	  enddo
	  X=dcmplx(BR,BI)
  END subroutine





  

  SUBROUTINE supGAUSS(A,B,X,NS,MS)
    use e_digit
    use quanju, only: XC
    implicit none 
    integer(long) NS,MS,I,J,JS(NS),K,IS,L
    real(double) D,P,Q,S,AR(NS,NS),AI(NS,NS),BR(NS,MS),BI(NS,MS)
    complex(double) A(NS,NS),B(NS,MS),X(NS,MS) 
      AR=real(A); AI=imag(A); BR=real(B); BI=imag(B)
      DO K=1,NS-1
		D=0d0
		DO J=K,NS
		  DO I=K,NS
		    P=AR(I,J)*AR(I,J)+AI(I,J)*AI(I,J)
			IF(P>D)THEN
			  D=P; JS(K)=J; IS=I
			ENDIF
          enddo
	    enddo
        !$OMP parallel do num_threads(XC) private(P) shared(AR,AI,K,IS) 
	    DO J=K,NS
		  P=AR(K,J); AR(K,J)=AR(IS,J); AR(IS,J)=P
		  P=AI(K,J); AI(K,J)=AI(IS,J); AI(IS,J)=P		   					  	    
        enddo
        !$OMP end parallel do
        !$OMP parallel do num_threads(XC) private(P) shared(BR,BI,K,IS) 
		do L=1,MS
	      P=BR(K,L); BR(K,L)=BR(IS,L); BR(IS,L)=P
		  P=BI(K,L); BI(K,L)=BI(IS,L); BI(IS,L)=P
		enddo
        !$OMP end parallel do
        !$OMP parallel do num_threads(XC) private(P) shared(AR,AI,K,JS) 
		DO I=1,NS
		  P=AR(I,K); AR(I,K)=AR(I,JS(K)); AR(I,JS(K))=P
		  P=AI(I,K); AI(I,K)=AI(I,JS(K)); AI(I,JS(K))=P
        enddo
        !$OMP end parallel do
        !$OMP parallel do num_threads(XC) private(P,Q,S) shared(AR,AI,K,D) 
		DO J=K+1,NS
		  P=AR(K,J)*AR(K,K)
		  Q=-AI(K,J)*AI(K,K)
		  S=(AR(K,K)-AI(K,K))*(AR(K,J)+AI(K,J))
		  AR(K,J)=(P-Q)/D
		  AI(K,J)=(S-P-Q)/D
        enddo
        !$OMP end parallel do
		do L=1,MS
	      P=BR(K,L)*AR(K,K)
		  Q=-BI(K,L)*AI(K,K)
		  S=(AR(K,K)-AI(K,K))*(BR(K,L)+BI(K,L))
		  BR(K,L)=(P-Q)/D
		  BI(K,L)=(S-P-Q)/D
		enddo
        !$OMP parallel do num_threads(XC) private(P,Q,S) shared(AR,AI,K) 
		DO J=K+1,NS
		  DO I=K+1,NS
			P=AR(I,K)*AR(K,J)
			Q=AI(I,K)*AI(K,J)
			S=(AR(I,K)+AI(I,K))*(AR(K,J)+AI(K,J))
			AR(I,J)=AR(I,J)-P+Q
			AI(I,J)=AI(I,J)-S+P+Q
          enddo
        enddo
        !$OMP end parallel do
        !$OMP parallel do num_threads(XC) private(P,Q,S) shared(BR,BI,K) 
        do I=K+1,NS
		  do L=1,MS
            P=AR(I,K)*BR(K,L)
		    Q=AI(I,K)*BI(K,L)
	   	    S=(AR(I,K)+AI(I,K))*(BR(K,L)+BI(K,L))
		    BR(I,L)=BR(I,L)-P+Q
	   	    BI(I,L)=BI(I,L)-S+P+Q
	      enddo
        enddo
        !$OMP end parallel do
      enddo
	  D=AR(NS,NS)*AR(NS,NS)+AI(NS,NS)*AI(NS,NS)
	  do L=1,MS
	    P=AR(NS,NS)*BR(NS,L)
	    Q=-AI(NS,NS)*BI(NS,L)
	    S=(AR(NS,NS)-AI(NS,NS))*(BR(NS,L)+BI(NS,L))
	    BR(NS,L)=(P-Q)/D
	    BI(NS,L)=(S-P-Q)/D  
	    DO I=NS-1,1,-1
	      DO J=I+1,NS
		    P=AR(I,J)*BR(J,L)
		    Q=AI(I,J)*BI(J,L)
		    S=(AR(I,J)+AI(I,J))*(BR(J,L)+BI(J,L))
		    BR(I,L)=BR(I,L)-P+Q
		    BI(I,L)=BI(I,L)-S+P+Q
          enddo
        enddo
        JS(NS)=NS
	    DO K=NS,1,-1
	      P=BR(K,L); BR(K,L)=BR(JS(K),L); BR(JS(K),L)=P
	   	  P=BI(K,L); BI(K,L)=BI(JS(K),L); BI(JS(K),L)=P
        enddo
	  enddo
      X=dcmplx(BR,BI)


  END subroutine
