


subroutine openfile

  implicit none
  integer(4) i,IP,U,ij,sz(3)
  character zf(3)
  character(2) bo,jd

    do i=1,300
      sz(1)=i/100
	  sz(2)=(i-sz(1)*100)/10
	  sz(3)=i-sz(1)*100-sz(2)*10
      zf(1)=char(sz(1)+48)
	  zf(2)=char(sz(2)+48)
      zf(3)=char(sz(3)+48)
      open(i,file='surface/'//zf(1)//zf(2)//zf(3)//'.txt')
    enddo

 
    open(1000,file='Gs1.txt')
    open(1001,file='Gv1.txt')
	open(1002,file='DM1.txt')  
	open(1003,file='DM2.txt')  
	open(1004,file='DM3.txt')     
	open(1005,file='cof.txt')
    open(1008,file='Fv.txt')
    open(1009,file='lm.txt')
    open(1010,file='out.txt')


	open(2001,file='K/KHH.txt',POSITION='APPEND')
    open(2002,file='K/KVV.txt',POSITION='APPEND')
    open(2003,file='K/KMM.txt',POSITION='APPEND')
    open(2004,file='K/KTT.txt',POSITION='APPEND')
    open(2005,file='K/KHM.txt',POSITION='APPEND')
    open(2006,file='K/KMH.txt',POSITION='APPEND') 

   
    do IP=1,3
      if(IP==1)then
        bo='P'
      elseif(IP==2)then
        bo='SV'
      else
        bo='SH'
      endif
      do U=1,4
        if(U==1)then
          jd='0'
        elseif(U==2)then
          jd='30'
        elseif(U==3)then
          jd='60'
        else
          jd='90'
        endif
        do i=1,6          
          ij=6*((IP-1)*4+U-1)+i
          open(3000+ij,file='delta/'//bo//jd//'_'//char(i+48)//'.txt',POSITION='APPEND')
        enddo
      enddo
    enddo


end subroutine
