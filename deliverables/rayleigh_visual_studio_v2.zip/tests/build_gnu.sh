#!/usr/bin/env bash
set -euo pipefail
base="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
: "${FC:=gfortran}"
for site in Site1 Site2 Site3; do
 mkdir -p "$base/$site/bin/Release"
 cd "$base/$site/bin/Release"
 "$FC" ${FC_EXTRA_FLAGS:-} -cpp -ffree-line-length-none -fallow-argument-mismatch -O2 -g -fopenmp -ffp-contract=off \
  -fcheck=all -ffpe-trap=invalid,zero,overflow ../../run_environment.F90 ../../main.f90 ../../indata.f90 \
  ../../openfile.f90 ../../region.f90 ../../dk.f90 ../../green.f90 ../../integral.f90 ../../gauss.f90 \
  ../../solv.f90 ../../free.f90 -l:liblapack.so.3 -l:libblas.so.3 -o "Rayleigh_$site" > compile_gnu.log 2>&1
 echo "$site: GNU compile passed"
done
