from pathlib import Path
import json,xml.etree.ElementTree as E,re
r=Path(__file__).resolve().parent.parent;checks=[]
for i in (1,2,3):
 d=r/f'Site{i}';t=E.parse(d/f'Rayleigh_Site{i}.vfproj')
 configs=t.findall('./Configurations/Configuration')
 assert {x.attrib['Name'] for x in configs}=={'Debug|x64','Release|x64'}
 refs=[x.attrib['RelativePath'] for x in t.findall('./Files/Filter/File')]
 for name in refs:assert (d/name.replace('\\','/')).is_file(),name
 assert len([x for x in refs if x.lower().endswith('.f90')])==11
 for c in configs:
  tool=c.find("Tool[@Name='VFFortranCompilerTool']")
  assert tool.attrib['UseMkl']=='mklSequential'
  assert '/D_WIN32' in tool.attrib['AdditionalOptions']
  assert c.find("Tool[@Name='VFLinkerTool']").attrib['StackReserveSize']=='1073741824'
 settings=(d/'run_settings.nml').read_text();assert 'nfreq=1' in settings and 'free_only=.false.' in settings
 for p in d.glob('*90'):
  for n,line in enumerate(p.read_text().splitlines(),1):
   assert len(line)<=132 or line.lstrip().startswith('!'),(p,n,len(line))
 sol=(r/f'OPEN_SITE{i}.sln').read_text(encoding='utf-8-sig')
 assert f'Site{i}\\Rayleigh_Site{i}.vfproj' in sol and 'Win32' not in sol
 checks.append({'site':i,'project_xml_valid':True,'referenced_files_exist':True,'source_count':11,'configurations':['Debug|x64','Release|x64'],'mkl':'sequential','default_points':1,'default_free_only':False,'all_source_lines_fit_132_columns':True})
(r/'tests/project_static_checks.json').write_text(json.dumps(checks,indent=2))
print('VS project static checks passed for all 3 sites')
