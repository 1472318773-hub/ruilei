"""Reproduce no-argument IDE startup from an unrelated working directory."""
from pathlib import Path
import subprocess,resource,json,os
root=Path(__file__).resolve().parent.parent
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
summary=[]
for points in (1,2):
 for n in (1,2,3):
  site=root/f'Site{n}';settings=site/'run_settings.nml';saved=settings.read_bytes()
  try:
   settings.write_text(f'&run\n nfreq={points}\n nthreads=1\n free_only=.true.\n/\n')
   before=set((site/'runs').glob('*')) if (site/'runs').exists() else set()
   p=subprocess.run([str(site/'bin/Release'/f'Rayleigh_Site{n}')],cwd='/tmp',capture_output=True,text=True,timeout=60)
   (root/'tests'/f'Site{n}_{points}pt_no_args.log').write_text(p.stdout+p.stderr)
   after=set((site/'runs').glob('*'));created=after-before
   assert p.returncode==0,p.stdout+p.stderr
   assert p.stdout.count('FREE_FIELD_COMPLETE')==points
   assert len(created)==1,created
   run=created.pop()
   assert len((run/'completed_frequencies.csv').read_text().splitlines())==1
   assert len(list((run/'K').glob('*.txt')))==6
   assert len(list((run/'delta').glob('*.txt')))==6
   assert all(f.stat().st_size==0 for f in (run/'K').glob('*.txt'))
   summary.append({'site':n,'points':points,'no_arguments':True,'working_directory':'unrelated /tmp','exit':p.returncode,'new_result_dir':run.name,'scope':'free field only'})
   print(summary[-1],flush=True)
  finally:settings.write_bytes(saved)
(root/'tests/ide_startup_summary.json').write_text(json.dumps(summary,indent=2))
