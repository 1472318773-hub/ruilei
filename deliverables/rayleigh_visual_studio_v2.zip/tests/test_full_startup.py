from pathlib import Path
import subprocess,resource,json,os
root=Path(__file__).resolve().parent.parent
soft,hard=resource.getrlimit(resource.RLIMIT_STACK);resource.setrlimit(resource.RLIMIT_STACK,(hard,hard))
exe=root/'Site1/bin/Release/Rayleigh_Site1'
result={'scope':'bounded full one-frequency startup','limit_wall_seconds':20,'windows_execution':False,'full_frequency_validated':False}
try:
 run_env=os.environ.copy()
 for key in ('OMP_STACKSIZE','GOMP_STACKSIZE','KMP_STACKSIZE'):run_env.pop(key,None)
 p=subprocess.run([str(exe)],cwd='/tmp',env=run_env,capture_output=True,text=True,timeout=20)
 text=p.stdout+p.stderr
 result.update(exit=p.returncode,timeout=False)
except subprocess.TimeoutExpired as e:
 text=e.stdout or ''
 if isinstance(text,bytes):text=text.decode(errors='replace')
 result.update(timeout=True,exit=None)
(root/'tests/full_startup.log').write_text(text)
result['entered_original_integral']='INTEGRAL_BLOCK_BEGIN' in text
result['frequency_complete']='FREQUENCY_COMPLETE' in text
(root/'tests/full_startup_summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result),flush=True)
if not result['entered_original_integral']:raise SystemExit('Full startup did not enter integral')
