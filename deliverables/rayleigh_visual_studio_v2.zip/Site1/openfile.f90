subroutine openfile
 use run_environment, only: output_file
 implicit none
 integer j
 character(8),parameter:: kn(6)=[character(8)::'KHH','KVV','KMM','KTT','KHM','KMH']
 character(8),parameter:: dn(6)=[character(8)::'deltx','delty','deltz','rx','ry','rz']
 open(1010,file=output_file('out.txt'),status='new',action='write')
 open(1012,file=output_file('completed_frequencies.csv'),status='new',action='write')
 write(1012,'(a)') '# index frequency_hz internal_w_rad_s'
 do j=1,6
   open(2000+j,file=output_file('K/'//trim(kn(j))//'.txt'),status='new',action='write')
   open(3000+j,file=output_file('delta/'//trim(dn(j))//'.txt'),status='new',action='write')
 enddo
end subroutine
