! IDE-friendly path/settings support only; no numerical solver formulas here.
module run_environment
 use iso_c_binding, only: c_int,c_char,c_null_char
 use omp_lib, only: omp_set_dynamic,omp_set_num_threads
 implicit none
 private
 public :: initialize_run,input_file,output_file
 character(:),allocatable :: project_dir,result_dir
 interface
#ifdef _WIN32
   function put_env(name,value) bind(C,name='_putenv_s') result(rc)
     import c_int,c_char
     character(kind=c_char),intent(in):: name(*),value(*)
     integer(c_int):: rc
   end function
#else
   function put_env(name,value,overwrite) bind(C,name='setenv') result(rc)
     import c_int,c_char
     character(kind=c_char),intent(in):: name(*),value(*)
     integer(c_int),value:: overwrite
     integer(c_int):: rc
   end function
#endif
 end interface
contains
 subroutine initialize_run(points,free_mode,thread_count)
   integer,intent(inout):: points,thread_count
   logical,intent(inout):: free_mode
   integer nfreq,nthreads,ios,unit,slash,i,tick,attempt,rc
   logical free_only,found
   character(4096) exe
   character(8) date
   character(10) time
   character(64) suffix,thread_text
   character(:),allocatable:: parent,command,settings
   namelist /run/ nfreq,nthreads,free_only
   call get_command_argument(0,exe,status=ios)
   if(ios/=0) error stop 'Cannot determine executable path'
   ! Project output layout: SiteN/bin/Debug|Release/Rayleigh_SiteN.exe.
   parent=trim(exe)
   do i=1,3
     slash=max(index(parent,'/',back=.true.),index(parent,achar(92),back=.true.))
     if(slash==0)exit
     if(slash==1)then
       parent=parent(:1)
     else
       parent=parent(:slash-1)
     endif
   enddo
   inquire(file=parent//'/CA.txt',exist=found)
   if(.not.found)then
     parent='.'
     inquire(file=parent//'/CA.txt',exist=found)
   endif
   if(.not.found)then
     parent='../..'
     inquire(file=parent//'/CA.txt',exist=found)
   endif
   if(.not.found) error stop 'CA.txt missing: keep the original SiteN/bin/configuration layout'
   project_dir=parent
   nfreq=1;nthreads=4;free_only=.false.
   settings=project_dir//'/run_settings.nml'
   open(newunit=unit,file=settings,status='old',action='read',iostat=ios)
   if(ios/=0)error stop 'Cannot open run_settings.nml'
   read(unit,nml=run,iostat=ios)
   close(unit)
   if(ios/=0)error stop 'Invalid run_settings.nml'
   if(command_argument_count()==0)then
     points=nfreq;free_mode=free_only
   endif
   if(points<1.or.points>300)error stop 'nfreq must be 1..300'
   if(nthreads<1.or.nthreads>64)error stop 'nthreads must be 1..64'
   thread_count=nthreads
   write(thread_text,'(i0)') thread_count
   call set_env('OMP_STACKSIZE','512M')
   call set_env('OMP_NUM_THREADS',trim(thread_text))
   call set_env('MKL_NUM_THREADS','1')
   call set_env('OPENBLAS_NUM_THREADS','1')
   call omp_set_dynamic(.false.)
   call omp_set_num_threads(thread_count)
   call date_and_time(date=date,time=time)
   call system_clock(count=tick)
   do attempt=1,100
     write(suffix,'(a,"T",a,"_",z8.8,"_",i3.3)') date,time(:6),tick,attempt
     result_dir=project_dir//'/runs/'//trim(suffix)
#ifdef _WIN32
     command='cmd /c mkdir "'//native_path(result_dir//'/K')//'" "'//native_path(result_dir//'/delta')//'"'
#else
     command='mkdir --parents -- '//shell_quote(project_dir//'/runs')
     call execute_command_line(command,exitstat=rc,cmdstat=ios)
     if(ios/=0.or.rc/=0)error stop 'Cannot create runs directory'
     command='mkdir -- '//shell_quote(result_dir)
     call execute_command_line(command,exitstat=rc,cmdstat=ios)
     if(ios/=0.or.rc/=0)cycle
     command='mkdir -- '//shell_quote(result_dir//'/K')//' '//shell_quote(result_dir//'/delta')
#endif
     call execute_command_line(command,exitstat=rc,cmdstat=ios)
     if(ios==0.and.rc==0)exit
   enddo
   if(ios/=0.or.rc/=0)error stop 'Cannot create a fresh result directory'
   write(*,*) 'PROJECT_DIRECTORY: ',project_dir
   write(*,*) 'RESULT_DIRECTORY: ',result_dir
   write(*,*) 'POINTS: ',points,' THREADS: ',thread_count,' FREE_ONLY: ',free_mode
   open(newunit=unit,file=result_dir//'/run_settings_used.txt',status='new',action='write')
   write(unit,nml=run)
   write(unit,*) 'effective_points=',points,' effective_free_only=',free_mode
   close(unit)
   flush(6)
 end subroutine
#ifdef _WIN32
 function native_path(path) result(result_path)
   character(*),intent(in)::path
   character(:),allocatable::result_path
   integer i
   result_path=path
   do i=1,len(result_path)
     if(result_path(i:i)=='/')result_path(i:i)=achar(92)
   enddo
 end function
#endif
 function input_file(name) result(path)
   character(*),intent(in):: name
   character(:),allocatable:: path
   path=project_dir//'/'//name
 end function
 function output_file(name) result(path)
   character(*),intent(in):: name
   character(:),allocatable:: path
   path=result_dir//'/'//name
 end function
 subroutine set_env(name,value)
   character(*),intent(in)::name,value
   integer(c_int) rc
#ifdef _WIN32
   rc=put_env(name//c_null_char,value//c_null_char)
#else
   rc=put_env(name//c_null_char,value//c_null_char,1_c_int)
#endif
   if(rc/=0)error stop 'Cannot initialize OpenMP environment'
 end subroutine
#ifndef _WIN32
 function shell_quote(text) result(quoted)
   character(*),intent(in)::text
   character(:),allocatable::quoted
   integer i
   quoted=achar(39)
   do i=1,len(text)
     if(text(i:i)==achar(39))then
       quoted=quoted//achar(39)//achar(92)//achar(39)//achar(39)
     else
       quoted=quoted//text(i:i)
     endif
   enddo
   quoted=quoted//achar(39)
 end function
#endif
end module
