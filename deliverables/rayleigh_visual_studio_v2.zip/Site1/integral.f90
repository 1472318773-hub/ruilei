 

subroutine integral(Gv1,Gs1)
        use quanju
    implicit none
    integer(long),parameter:: NJ=1200,ND=100
    integer(long) U,i,j,i1,j1,j11,id,ij,G1,G2,G3,G4,ierr,iL,iR
    real(double) length,thta,time
    complex(double) kx,ky,KXY,Gs1(:,:),Gv1(:,:)
    complex(double),allocatable:: T1(:,:,:,:),T2(:,:,:,:),T3(:,:,:,:)
    complex(double),allocatable:: W1(:,:,:,:),W2(:,:,:,:),W3(:,:,:,:)
    complex(double) RT1(6,N1+NN1,M,N1+NN1),RT2(6,N1+NN1,M,N1+NN1),RT3(6,N1+NN1,M,N1+NN1),RW1(3,N1+NN1,M,N1+NN1), &
  & RW2(3,N1+NN1,M,N1+NN1),RW3(3,N1+NN1,M,N1+NN1)
    complex(double) UWUNIT(2,4,N1+1,N1),TXYZUNIT(4,4,N1+1,N1),VVUNIT(2,N1+1,N1),tYzUNIT(2,N1+1,N1),tYXUNIT(2,N1+1,N1)
    complex(double) UWBUNIT(2,4,N1+1),TXYZBUNIT(4,4,N1+1),VVBUNIT(N1+1),tYzBUNIT(N1+1),tYXBUNIT(N1+1)
    real(double)  DUANK(NJ),DUANKX(ND,NJ),DUANKY(ND,NJ),DKS(NJ)

      ! Allocatable PRIVATE arrays keep their shape and live on the heap per thread.
      ! This changes storage only; all arithmetic and loop order below are unchanged.
      allocate(T1(6,N1+NN1,M,N1+NN1),T2(6,N1+NN1,M,N1+NN1),T3(6,N1+NN1,M,N1+NN1))
      allocate(W1(3,N1+NN1,M,N1+NN1),W2(3,N1+NN1,M,N1+NN1),W3(3,N1+NN1,M,N1+NN1))
      call region(DUANK,DUANKX,DUANKY,DKS,NJ,ND)

      T1=(0d0,0d0);T2=(0d0,0d0);T3=(0d0,0d0);W1=(0d0,0d0);W2=(0d0,0d0);W3=(0d0,0d0)
      RT1=(0d0,0d0);RT2=(0d0,0d0);RT3=(0d0,0d0);RW1=(0d0,0d0);RW2=(0d0,0d0);RW3=(0d0,0d0)
      
      UWUNIT=(0.0,0.0);TXYZUNIT=(0.0,0.0);VVUNIT=(0.0,0.0);tYzUNIT=(0.0,0.0);tYXUNIT=(0.0,0.0)
      UWBUNIT=(0.0,0.0);TXYZBUNIT=(0.0,0.0);VVBUNIT=(0.0,0.0);tYzBUNIT=(0.0,0.0);tYXBUNIT=(0.0,0.0)
      
      !$OMP parallel num_threads(XC) default(shared) private(I,J,KX,KY,KXY,length,U,UWUNIT,TXYZUNIT,VVUNIT,tYzUNIT, &
!$OMP& tYXUNIT,UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT,T1,T2,T3,w1,w2,w3)
          T1=(0d0,0d0);T2=(0d0,0d0);T3=(0d0,0d0);W1=(0d0,0d0);W2=(0d0,0d0);W3=(0d0,0d0);UWUNIT=(0d0,0d0); &
  & TXYZUNIT=(0d0,0d0);VVUNIT=(0d0,0d0);tYzUNIT=(0d0,0d0);tYXUNIT=(0d0,0d0);UWBUNIT=(0d0,0d0);TXYZBUNIT=(0d0,0d0); &
  & VVBUNIT=(0d0,0d0);tYzBUNIT=(0d0,0d0);tYXBUNIT=(0d0,0d0)
          !$OMP do
      do I=1,NJ
        Kxy=DUANK(I);   length=DKS(I)
        if(mod(I-1,25)==0)then
          !$OMP critical(progress_log)
          write(*,*) 'INTEGRAL_BLOCK_BEGIN',I,'OF',NJ
          flush(6)
          !$OMP end critical(progress_log)
        endif
        CALL DK(KXY)
        do U=1,N1 
              CALL GreenUNIT(kxy,U,UWUNIT(:,:,:,U),TXYZUNIT(:,:,:,U),VVUNIT(:,:,U),tYzUNIT(:,:,U),tYXUNIT(:,:,U)) 
        end do
        CALL GreenbottomUNIT(kxy,UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
        DO J=1,ND !!!!!!!!!!!!
          KX=DUANKX(J,I);  KY=DUANKY(J,I)
          do U=1,N1 
                call GreenUNITTON(kx,ky,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:,:,U), &
  & W2(:,:,:,U),W3(:,:,:,U),UWUNIT(:,:,:,U),TXYZUNIT(:,:,:,U),VVUNIT(:,:,U),tYzUNIT(:,:,U),tYXUNIT(:,:,U))
            call GreenUNITTON(kY,kX,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:,:, &
  & U),W2(:,:,:,U),W3(:,:,:,U),UWUNIT(:,:,:,U),TXYZUNIT(:,:,:,U),VVUNIT(:,:,U),tYzUNIT(:,:,U),tYXUNIT(:,:,U))
          enddo
          
          DO U=N1+1,N1+NN1
            CALL GreenbUNITTON(kx,ky,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:, &
  & :,U),W2(:,:,:,U),W3(:,:,:,U),UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
            CALL GreenbUNITTON(-kx,ky,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:, &
  & :,U),W2(:,:,:,U),W3(:,:,:,U),UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
            CALL GreenbUNITTON(kY,kX,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:, &
  & :,U),W2(:,:,:,U),W3(:,:,:,U),UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
            CALL GreenbUNITTON(-kY,kX,KXY,U,length,xmx2(:,:,U),ym2(:,:),T1(:,:,:,U),T2(:,:,:,U),T3(:,:,:,U),W1(:,:, &
  & :,U),W2(:,:,:,U),W3(:,:,:,U),UWBUNIT,TXYZBUNIT,VVBUNIT,tYzBUNIT,tYXBUNIT)
          END DO
        END DO
        if(I<=5.or.mod(I,5)==0)then
          !$OMP critical(progress_log)
          write(*,*) 'INTEGRAL_BLOCK_COMPLETE',I,'OF',NJ
          flush(6)
          !$OMP end critical(progress_log)
        endif
      enddo
      !$OMP end do
           !$OMP critical
              RT1=RT1+T1;RT2=RT2+T2;RT3=RT3+T3;RW1=RW1+W1;RW2=RW2+W2;RW3=RW3+W3
           !$OMP end critical
      !$OMP end parallel
      deallocate(T1,T2,T3,W1,W2,W3)
      

      do U=1,N1+NN1
        do i=1,N1+NN1
            do j=1,M
              Gs1((i-1)*M+j,U)=RT1(1,i,j,U)*nx2(i,j)+RT1(4,i,j,U)*ny2(i,j)+RT1(5,i,j,U)*nz2(i,j)
                  Gs1(NT+(i-1)*M+j,U)=RT1(2,i,j,U)*ny2(i,j)+RT1(4,i,j,U)*nx2(i,j)+RT1(6,i,j,U)*nz2(i,j)
                  Gs1(2*NT+(i-1)*M+j,U)=RT1(3,i,j,U)*nz2(i,j)+RT1(5,i,j,U)*nx2(i,j)+RT1(6,i,j,U)*ny2(i,j)
                  
                  Gs1((i-1)*M+j,(N1+NN1)+U)=RT2(1,i,j,U)*nx2(i,j)+RT2(4,i,j,U)*ny2(i,j)+RT2(5,i,j,U)*nz2(i,j)
                  Gs1(NT+(i-1)*M+j,(N1+NN1)+U)=RT2(2,i,j,U)*ny2(i,j)+RT2(4,i,j,U)*nx2(i,j)+RT2(6,i,j,U)*nz2(i,j)
                  Gs1(2*NT+(i-1)*M+j,(N1+NN1)+U)=RT2(3,i,j,U)*nz2(i,j)+RT2(5,i,j,U)*nx2(i,j)+RT2(6,i,j,U)*ny2(i,j)
                      
                      Gs1((i-1)*M+j,2*(N1+NN1)+U)=RT3(1,i,j,U)*nx2(i,j)+RT3(4,i,j,U)*ny2(i,j)+RT3(5,i,j,U)*nz2(i,j)
                  Gs1(NT+(i-1)*M+j,2*(N1+NN1)+U)=RT3(2,i,j,U)*ny2(i,j)+RT3(4,i,j,U)*nx2(i,j)+RT3(6,i,j,U)*nz2(i,j)
                  Gs1(2*NT+(i-1)*M+j,2*(N1+NN1)+U)=RT3(3,i,j,U)*nz2(i,j)+RT3(5,i,j,U)*nx2(i,j)+RT3(6,i,j,U)*ny2(i,j)
                      
                      Gv1((i-1)*M+j,U)=RW1(1,i,j,U)
                  Gv1(NT+(i-1)*M+j,U)=RW1(2,i,j,U)
                  Gv1(2*NT+(i-1)*M+j,U)=RW1(3,i,j,U)
                      
                      Gv1((i-1)*M+j,(N1+NN1)+U)=RW2(1,i,j,U)
                  Gv1(NT+(i-1)*M+j,(N1+NN1)+U)=RW2(2,i,j,U)
                  Gv1(2*NT+(i-1)*M+j,(N1+NN1)+U)=RW2(3,i,j,U)
                      
                      Gv1((i-1)*M+j,2*(N1+NN1)+U)=RW3(1,i,j,U)
                  Gv1(NT+(i-1)*M+j,2*(N1+NN1)+U)=RW3(2,i,j,U)
                  Gv1(2*NT+(i-1)*M+j,2*(N1+NN1)+U)=RW3(3,i,j,U)
            enddo
            IF(U<=N1.AND.I==U)THEN
            Gs1(M*(i-1)+1,U)=Gs1(M*(i-1)+1,U)+DS2(U)/sa(U)/2
                Gs1(NT+M*(i-1)+1,(N1+NN1)+U)=Gs1(NT+M*(i-1)+1,(N1+NN1)+U)+DS2(U)/sa(U)/2
                Gs1(2*NT+M*(i-1)+1,2*(N1+NN1)+U)=Gs1(2*NT+M*(i-1)+1,2*(N1+NN1)+U)+DS2(U)/sa(U)/2
                END IF
        enddo
      enddo



end subroutine
